import pathlib,json,gzip,hashlib,itertools,collections,subprocess,posixpath,tarfile
R=pathlib.Path('/Users/ankitdas/.codex/worktrees/component-comparison/openui');L=R/'examples/miscellaneous/component-comparison';B=L/'evidence/bench';P=pathlib.Path('/private/tmp/openui-finalmatrix-independent-audit');N=B/'templates-cf1';O=B/'final';HEAD='2d03fcf6b110c52d72fc75e2020b225c94346f9f';CAND='cf1a8a88123b9a577c9cb43ae69d857ea6242f11'
def sha(b):return hashlib.sha256(b).hexdigest()
def j(p):return json.loads(gzip.decompress(p.read_bytes()) if p.suffix=='.gz' else p.read_bytes())
def save(n,x):(P/n).write_text(json.dumps(x,indent=2)+'\n')
# Verify committed evidence, manifests and exact four uncompressed run identities.
manifest=j(N/'manifest.json');verified=[]
for x in manifest:
 f=N/x['file'];b=f.read_bytes();assert len(b)==x['bytes'] and sha(b)==x['sha256'];committed=subprocess.check_output(['git','show',HEAD+':'+str(f.relative_to(R))],cwd=R);assert b==committed;verified.append(x)
new=j(N/'reconciliation.json.gz');old=j(O/'reconciliation.json.gz');summary=j(N/'summary.json');runs=[];checks=[]
for i in range(1,5):
 name=f'2026-10-26-integrated-cf1-s{i}';p=N/(name+'.json.gz');b=gzip.decompress(p.read_bytes());run=json.loads(b);local=(L/'.bench-runs'/name/'run.json').read_bytes();assert b==local;identity=next(s for s in summary['sourceRuns'] if s['id']==name);assert sha(b)==identity['sha256'];assert run['status']=='completed';runs.append(run)
 first=run['provenance'];verifiedArtifacts=[]
 for a in first['artifacts']:
  f=L/'.artifacts'/a['file'];assert sha(f.read_bytes())==a['sha256'];verifiedArtifacts.append(a)
 for f in first['bundles']:
  b=(L/'.bench-runs'/name/'runtime'/f['path']).read_bytes();assert sha(b)==f['sha256']
 for f in first['runnerFiles']:
  b=(L/'bench'/f['file']).read_bytes();assert sha(b)==f['sha256']
 for host,detail in first['hostFixtures']['files'].items():
  assert sha((L/'.bench-runs'/name/'runtime/bench-host'/(host+'.css')).read_bytes())==detail['sha256']
 checks.append({'run':name,'runSHA256':identity['sha256'],'runBytes':len(local),'recorded':len(run['results']),'bundlesVerified':len(first['bundles']),'runnerFiles':first['runnerFiles'],'artifactHashes':verifiedArtifacts,'browser':first['browser'],'normalization':run['normalization']})
# Independently reconstruct cells and verdicts, don't use supplied reconciliation/model functions.
cases={c['id']:c for run in runs for c in run['cases']};assert len(cases)==218
expected={f'{c["id"]}--{env}--{width}--{theme}--{delivery}' for c in cases.values() for env,width,theme,delivery in itertools.product(['plain','tailwind3-before','tailwind3-after','tailwind4-before','tailwind4-after'],[390,768,1280],['light','dark'],c['deliveries'])};assert len(expected)==12450
source={};duplicates=[]
for run in runs:
 for r in run['results']:
  k=r['cell']['id'];
  if k in source:duplicates.append(k)
  source[k]=(run['id'],r)
assert not duplicates and set(source)==expected
nm={r['cell']['id']:r for r in new['results']};om={r['cell']['id']:r for r in old['results']};assert set(nm)==expected and len(nm)==len(new['results'])
verdictErrors=[];sourceErrors=[];caseVersionErrors=[]
for k,r in nm.items():
 statuses=[l['status'] for l in r['layers'].values()];v=next((v for v in ['Fail','Review','Known issue','Not covered'] if v in statuses), 'Not applicable' if all(s=='Not applicable' for s in statuses) else 'Pass');
 if v!=r['verdict']:verdictErrors.append(k)
 runid,s=source[k]
 if r['sourceRun']!=runid or {x:y for x,y in r.items() if x not in ['sourceRun','sourceStatus','sourceRunner','caseVersion']}!=s:sourceErrors.append(k)
 if r['caseVersion']!=cases[r['cell']['caseId']]['version'] or r['caseVersion']!=om[k]['caseVersion']:caseVersionErrors.append(k)
assert not verdictErrors and not sourceErrors and not caseVersionErrors
counts=dict(collections.Counter(r['verdict'] for r in nm.values()));assert all(new['summary']['counts'].get(k)==v for k,v in counts.items());assert new['summary']['executed']==12450 and all(r['executed'] for r in nm.values());assert not new['missing'] and not new['superseded'];assert not new['priorFindings']
# Same case definition/known issues, not just same stored version string.
oldRunCases={}
for run in old['sourceRuns']:
 f=O/(run['id']+'.json.gz')
 if f.exists():oldRunCases.update({c['id']:c for c in j(f)['cases']})
caseDiffs=[k for k in cases if oldRunCases.get(k)!=cases[k]];assert not caseDiffs
# Do not collapse failure-layer details or relabel repeat differences.
deltas=[]
for k,r in nm.items():
 if r['verdict']!=om[k]['verdict']:
  deltas.append({'id':k,'oldVerdict':om[k]['verdict'],'newVerdict':r['verdict'],'oldSourceRun':om[k]['sourceRun'],'newSourceRun':r['sourceRun'],'oldLayers':om[k]['layers'],'newLayers':r['layers'],'newEvidence':r['evidence']})
newReviews=[d for d in deltas if d['oldVerdict']=='Pass' and d['newVerdict']=='Review'];newFails=[d for d in deltas if d['newVerdict']=='Fail'];assert len(newReviews)==7 and len(newFails)==4
layerChanges=[]
for k,r in nm.items():
 for layer in r['layers']:
  if om[k]['layers'].get(layer,{}).get('status')!=r['layers'][layer]['status']:layerChanges.append({'id':k,'layer':layer,'old':om[k]['layers'].get(layer,{}).get('status'),'new':r['layers'][layer]['status']})
# Package source-map contents bind real archived implementation source to candidate commit.
sourceBindings=[]
for a in runs[0]['provenance']['artifacts']:
 if a['name'] not in ['@openuidev/react-components','@openuidev/kits']:continue
 prefix='packages/react-components/' if a['name'].endswith('react-components') else 'packages/kits/';data={};external=0
 with tarfile.open(L/'.artifacts'/a['file']) as t:
  for member in t.getmembers():
   if not member.name.endswith('.map'):continue
   m=json.loads(t.extractfile(member).read())
   for src,content in zip(m.get('sources',[]),m.get('sourcesContent',[])):
    resolved=posixpath.normpath(posixpath.join(posixpath.dirname(member.name),src))
    if content is not None and resolved.startswith('package/src/'):
     f=prefix+resolved.removeprefix('package/');h=sha(content.encode());assert f not in data or data[f]==h;data[f]=h
    else:external+=1
 mismatches=[]
 for f,h in data.items():
  try:git=sha(subprocess.check_output(['git','show',CAND+':'+f],cwd=R))
  except subprocess.CalledProcessError:git=None
  if git!=h:mismatches.append({'file':f,'mapHash':h,'candidateHash':git})
 sourceBindings.append({'package':a['name'],'archiveSHA256':a['sha256'],'uniqueSourceFiles':len(data),'externalOrNonSourceEntries':external,'mismatches':mismatches,'hashes':data})
assert all(not b['mismatches'] for b in sourceBindings)
# Benchmark runner/browser/theme/lock/bundles identical between new shards; legacy archive unchanged.
identities=[{k:run['provenance'][k] for k in ['runnerVersion','runnerFiles','browser','artifacts','bundles','lockSha256','registries','hostFixtures']} for run in runs];assert all(x==identities[0] for x in identities)
oldProv=old['sourceRuns'][0]['provenance'];oldIdentityDeltas={k:{'old':oldProv.get(k),'new':identities[0].get(k)} for k in ['runnerVersion','runnerFiles','browser','lockSha256','registries','hostFixtures'] if oldProv.get(k)!=identities[0].get(k)}
save('integrity.json',{'evidenceCommit':HEAD,'candidateCommit':CAND,'manifestFiles':len(verified),'verifiedManifest':verified,'sourceRunChecks':checks,'matrix':{'cases':218,'expected':len(expected),'executed':len(nm),'counts':counts,'duplicateCells':duplicates,'missing':new['missing'],'superseded':new['superseded'],'verdictErrors':verdictErrors,'sourceRecordErrors':sourceErrors,'caseVersionErrors':caseVersionErrors,'caseDefinitionChanges':caseDiffs},'identityChangesVsBaseline':oldIdentityDeltas})
save('candidate-source-bindings.json',sourceBindings);save('all-verdict-deltas.json',deltas);save('layer-status-deltas.json',layerChanges);save('seven-new-review-cells.json',newReviews);save('four-new-fail-cells.json',newFails)
print(json.dumps({'verifiedManifestFiles':len(verified),'counts':counts,'sourceBindings':[(b['package'],b['uniqueSourceFiles'],len(b['mismatches'])) for b in sourceBindings],'verdictChanges':len(deltas),'newReviews':len(newReviews),'newFailures':len(newFails),'layerChanges':len(layerChanges),'identityChanges':list(oldIdentityDeltas)}))
