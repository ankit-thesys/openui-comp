import fs from "node:fs/promises";
import { createRequire } from "node:module";
const req = createRequire(
  "/Users/ankitdas/.codex/worktrees/2d0f/openui/packages/react-ui-core/package.json",
);
export const { chromium } = req("playwright");
export const out = "/private/tmp/react-components-rename-browser";
export const executablePath =
  "/private/tmp/beta17-cft/156.0.8078.47/chrome-mac-arm64/Google Chrome for Testing.app/Contents/MacOS/Google Chrome for Testing";
export const hosts = ["plain", "tailwind3", "tailwind4"].flatMap((host) =>
  ["before", "after"].map((order) => ({ host, order })),
);
export const schemes = ["default", "cyberpunk", "crimson-desert"].flatMap(
  (preset) => ["light", "dark"].map((mode) => ({ preset, mode, full: false })),
);
export const fullSchemes = ["cyberpunk", "crimson-desert"].flatMap((preset) =>
  ["light", "dark"].map((mode) => ({ preset, mode, full: true })),
);
export async function settle(page, ms = 0) {
  await page.evaluate(
    () =>
      new Promise((resolve) =>
        requestAnimationFrame(() => requestAnimationFrame(resolve)),
      ),
  );
  if (ms) await page.waitForTimeout(ms);
}
export async function openPage(
  browser,
  id,
  host = "plain",
  order = "before",
  width = 1280,
) {
  const page = await browser.newPage({ viewport: { width, height: 1000 } });
  page.verificationErrors = [];
  page.externalRequests = [];
  page.on("pageerror", (e) => page.verificationErrors.push(String(e)));
  await page.route("**/*", (r) => {
    const u = r.request().url();
    if (!u.startsWith("http://127.0.0.1:4322/") && !u.startsWith("data:")) {
      page.externalRequests.push(u);
      return r.abort();
    }
    return r.continue();
  });
  await page.goto(`http://127.0.0.1:4322/${id}/?host=${host}&order=${order}`);
  await page.waitForFunction(
    () =>
      window.fixture &&
      window.themeProbes &&
      document.querySelector(".openui-input"),
  );
  if (order === "after")
    await page.addStyleTag({
      url: `http://127.0.0.1:4322/${id}/host/${host}.css`,
    });
  await settle(page, 220);
  const ready = await page.evaluate(() => {
    let rules = 0,
      hostRules = 0;
    for (const s of document.styleSheets) {
      try {
        rules += s.cssRules.length;
        if (s.href?.includes("/host/")) hostRules += s.cssRules.length;
      } catch {}
    }
    return {
      rules,
      hostRules,
      sheets: [...document.styleSheets].map((s) => ({
        href: s.href,
        id: s.ownerNode?.id,
        css: s.cssRules?.length,
      })),
      input: getComputedStyle(document.querySelector(".openui-input")).font,
      presets: window.fixture.presetHashes,
    };
  });
  if (!ready.hostRules || ready.rules < 5)
    throw Error("Stylesheet readiness failure " + JSON.stringify(ready));
  page.cssReadiness = ready;
  return page;
}
export async function render(page, config) {
  await page.mouse.move(-10, -10);
  await page.evaluate((c) => {
    document.activeElement?.blur();
    scrollTo(0, 0);
    window.fixture.render(c);
  }, config);
  await settle(page, 220);
  const error = await page.evaluate(() => window.fixtureObservations.errors);
  if (error.length) throw Error("Fixture error " + error.join("; "));
}
export async function save(name, data) {
  await fs.writeFile(
    out + "/" + name + ".json",
    JSON.stringify(data, null, 2) + "\n",
  );
}
