import fs from "node:fs/promises";
import { createRequire } from "node:module";
import { createHash } from "node:crypto";
const req = createRequire(
  "/Users/ankitdas/.codex/worktrees/production-core-kits/openui/packages/react-ui/package.json",
);
const { build } = await import(req.resolve("vite"));
const out = "/private/tmp/important-pr42-retest",
  id = process.argv[2] ?? "baseline",
  arm = process.argv[3] ?? "new";
let origins = [];
await build({
  root: out + "/consumer",
  base: "/" + id + "/",
  configFile: false,
  plugins: [
    {
      name: "verification-origin-audit",
      generateBundle(_, bundle) {
        for (const item of Object.values(bundle))
          if (item.type === "chunk")
            for (const source of Object.keys(item.modules))
              origins.push(source);
      },
    },
  ],
  build: {
    rollupOptions: {
      input:
        out +
        "/consumer/" +
        (arm === "legacy"
          ? "legacy.html"
          : arm === "wiring"
            ? "wiring.html"
            : "index.html"),
    },
    outDir: out + "/browser-dist/" + id,
    emptyOutDir: true,
  },
});
await fs.writeFile(
  out + "/browser-dist/" + id + "/origin-audit.json",
  JSON.stringify(
    {
      arm,
      id,
      modules: [...new Set(origins)],
      forbiddenCrossArmModules: origins.filter((s) =>
        arm === "legacy"
          ? s.includes("/node_modules/@openuidev/react-ui-core/")
          : s.includes("/node_modules/@openuidev/react-ui/"),
      ),
    },
    null,
    2,
  ) + "\n",
);
