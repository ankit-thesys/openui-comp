import http from "node:http";
import fs from "node:fs/promises";
import path from "node:path";
const root = "/private/tmp/important-pr42-retest/browser-dist";
const types = {
  ".html": "text/html",
  ".js": "text/javascript",
  ".css": "text/css",
  ".json": "application/json",
  ".svg": "image/svg+xml",
  ".woff": "font/woff",
  ".woff2": "font/woff2",
  ".ttf": "font/ttf",
  ".png": "image/png",
};
const server = http.createServer(async (req, res) => {
  try {
    const u = new URL(req.url, "http://127.0.0.1"),
      parts = u.pathname.split("/").filter(Boolean),
      id = parts.shift();
    if (!id || !/^[-a-z0-9]+$/.test(id)) throw Error("Invalid artifact id");
    const rel = parts.length
      ? parts.join("/")
      : id === "legacy"
        ? "legacy.html"
        : "index.html";
    const file = path.resolve(root, id, rel);
    if (!file.startsWith(path.resolve(root, id) + "/"))
      throw Error("Invalid path");
    let body = await fs.readFile(file);
    if (
      path.extname(file) === ".html" &&
      u.searchParams.get("order") === "before"
    ) {
      const host = u.searchParams.get("host") ?? "plain";
      if (!["plain", "tailwind3", "tailwind4"].includes(host))
        throw Error("Invalid host");
      body = Buffer.from(
        body
          .toString()
          .replace(
            "</head>",
            `<link data-host="${host}" rel="stylesheet" href="/${id}/host/${host}.css"></head>`,
          ),
      );
    }
    res.writeHead(200, {
      "Content-Type": types[path.extname(file)] ?? "application/octet-stream",
      "Cache-Control": "no-store",
      "X-Verification-Artifact": id,
    });
    res.end(body);
  } catch (e) {
    res.writeHead(404);
    res.end(String(e));
  }
});
server.listen(4321, "127.0.0.1", () =>
  process.stdout.write("Verification static server ready on 4321\n"),
);
