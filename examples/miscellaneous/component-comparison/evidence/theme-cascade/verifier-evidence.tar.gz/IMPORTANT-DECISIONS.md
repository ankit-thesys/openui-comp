# Important-removal decisions

Approved removals: **none yet**. Every candidate below is prepared but not runtime verified. Production is unchanged.

| ID | Source | Property | Decision |
| --- | --- | --- | --- |
| 01 | packages/react-ui-core/src/components/CodeBlock/codeBlock.styles.ts:16 | margin | Not covered; no removal approval |
| 02 | packages/react-ui-core/src/components/MarkDownRenderer/markdown.styles.ts:82 | padding | Not covered; no removal approval |
| 03 | packages/react-ui-core/src/components/MarkDownRenderer/markdown.styles.ts:83 | marginTop | Not covered; no removal approval |
| 04 | packages/react-ui-core/src/components/MarkDownRenderer/markdown.styles.ts:84 | marginBottom | Not covered; no removal approval |
| 05 | packages/react-ui-core/src/components/MarkDownRenderer/markdown.styles.ts:85 | marginTop | Not covered; no removal approval |
| 06 | packages/react-ui-core/src/components/MarkDownRenderer/markdown.styles.ts:86 | marginBottom | Not covered; no removal approval |
| 07 | packages/react-ui-core/src/components/Slider/sliderBlock.styles.ts:43 | borderColor | Not covered; no removal approval |
| 08 | packages/react-ui-core/src/components/Slider/sliderBlock.styles.ts:47 | text-align | Not covered; no removal approval |
| 09 | packages/react-ui-core/src/components/Slider/sliderBlock.styles.ts:48 | paddingLeft | Not covered; no removal approval |
| 10 | packages/react-ui-core/src/components/Slider/sliderBlock.styles.ts:49 | paddingRight | Not covered; no removal approval |
| 11 | packages/react-ui-core/src/components/Sources/listedSources.styles.ts:26 | width | Not covered; no removal approval |
| 12 | packages/react-ui-core/src/components/Sources/listedSources.styles.ts:27 | padding | Not covered; no removal approval |
| 13 | packages/react-ui-core/src/components/Sources/listedSources.styles.ts:28 | borderRadius | Not covered; no removal approval |
| 14 | packages/react-ui-core/src/components/Sources/listedSources.styles.ts:30 | backgroundColor | Not covered; no removal approval |
| 15 | packages/react-ui-core/src/components/Sources/listedSources.styles.ts:32 | backgroundColor | Not covered; no removal approval |
| 16 | packages/react-ui-core/src/components/Sources/listedSources.styles.ts:33 | borderColor | Not covered; no removal approval |
