import fs from "node:fs/promises";
import path from "node:path";
import { createHash } from "node:crypto";
import { execFileSync } from "node:child_process";
const out = "/private/tmp/openui-theme-cascade-verification",
  prod = "/Users/ankitdas/.codex/worktrees/production-core-kits/openui",
  base = out + "/source-candidates/base",
  items = JSON.parse(
    await fs.readFile(out + "/counterfactual-manifest.json", "utf8"),
  ),
  provenance = JSON.parse(
    await fs.readFile(out + "/source-provenance.json", "utf8"),
  );
const hash = (b) => createHash("sha256").update(b).digest("hex");
let results = [];
const run = async (exe, args, cwd, log) => {
  const fd = await fs.open(log, "w");
  try {
    execFileSync(exe, args, {
      cwd,
      stdio: ["ignore", fd.fd, fd.fd],
      env: {
        ...process.env,
        npm_config_cache: "/private/tmp/chat16-npm-cache",
      },
    });
  } finally {
    await fd.close();
  }
};
for (const item of items) {
  const id = "remove-" + item.id,
    dir = out + "/source-candidates/" + id,
    core = dir + "/packages/react-ui-core",
    artifactDir = out + "/artifacts/" + id;
  await fs.mkdir(core, { recursive: true });
  await fs.copyFile(base + "/tsconfig.json", dir + "/tsconfig.json");
  for (const name of [
    "package.json",
    "tsconfig.json",
    "tsdown.config.ts",
    "README.md",
    "THIRD_PARTY_NOTICES.md",
  ])
    await fs.copyFile(
      base + "/packages/react-ui-core/" + name,
      core + "/" + name,
    );
  await fs.cp(base + "/packages/react-ui-core/src", core + "/src", {
    recursive: true,
  });
  for (const [d, s] of [
    [dir + "/node_modules", prod + "/node_modules"],
    [core + "/node_modules", prod + "/packages/react-ui-core/node_modules"],
  ]) {
    try {
      await fs.symlink(s, d, "dir");
    } catch (e) {
      if (e.code !== "EEXIST") throw e;
    }
  }
  await fs.copyFile(
    out + "/counterfactuals/" + item.id + "/remove-only.ts",
    dir + "/" + item.file,
  );
  const changed = [];
  for (const [file, expected] of Object.entries(provenance.sourceHashes)) {
    if (!file.startsWith("packages/react-ui-core/")) continue;
    const actual = hash(await fs.readFile(dir + "/" + file));
    if (actual !== expected) changed.push(file);
  }
  if (changed.length !== 1 || changed[0] !== item.file)
    throw Error("Unexpected candidate source delta " + id);
  await run(
    prod + "/node_modules/.bin/tsdown",
    [],
    core,
    out + "/" + id + "-package-build.log",
  );
  await fs.mkdir(artifactDir, { recursive: true });
  await run(
    "npm",
    [
      "pack",
      "--ignore-scripts",
      "--cache",
      "/private/tmp/chat16-npm-cache",
      "--pack-destination",
      artifactDir,
      "--json",
    ],
    core,
    out + "/" + id + "-pack.json",
  );
  const tar = artifactDir + "/openuidev-react-ui-core-0.0.0-beta.0.tgz";
  await run(
    "npm",
    [
      "install",
      "--offline",
      "--cache",
      "/private/tmp/chat16-npm-cache",
      "--ignore-scripts",
      "--no-audit",
      "--no-fund",
      tar,
    ],
    out + "/consumer",
    out + "/" + id + "-install.log",
  );
  await run(
    "node",
    [out + "/build-fixture.mjs", id],
    out + "/consumer",
    out + "/" + id + "-browser-build.log",
  );
  const result = {
    id,
    productionHead: provenance.head,
    changedSource: changed,
    sourceSha256: item.candidateSha256,
    archive: tar,
    archiveSha256: hash(await fs.readFile(tar)),
    browserEntrySha256: hash(
      await fs.readFile(out + "/browser-dist/" + id + "/index.html"),
    ),
    packageBuild: "Passed",
    normalInstalledBrowserBuild: "Passed",
    browserTest: "Pending",
  };
  results.push(result);
  await fs.writeFile(
    out + "/candidate-artifacts.json",
    JSON.stringify(results, null, 2) + "\n",
  );
  process.stdout.write(id + " built and packed " + result.archiveSha256 + "\n");
}
