import fs from "node:fs/promises";
import {
  chromium,
  executablePath,
  out,
  hosts,
  schemes,
  fullSchemes,
  openPage,
  render,
  settle,
  save,
} from "./browser-common.mjs";
const browser = await chromium.launch({ executablePath, headless: true });
let results = [];
try {
  for (const host of hosts) {
    const pages = {};
    for (const arm of ["baseline", "legacy"]) {
      pages[arm] = await openPage(browser, "v2-" + arm, host.host, host.order);
      await pages[arm].addStyleTag({
        url: `http://127.0.0.1:4317/v2-${arm}/host/consumer-overrides.css`,
      });
    }
    for (const scheme of [...schemes, ...fullSchemes])
      for (const width of [390, 1280]) {
        const row = { ...host, ...scheme, width, arms: {} };
        for (const arm of ["baseline", "legacy"]) {
          const page = pages[arm];
          await page.setViewportSize({ width, height: 1000 });
          await render(page, scheme);
          row.arms[arm] = await page.evaluate(() => {
            const sels = {
              inlineInput: '[aria-label="Inline override input"]',
              classInput: '[aria-label="Class override input"]',
              classLabel: '[data-case="public-overrides"] label',
              inlineButton: '[data-case="public-overrides"] button',
            };
            return Object.fromEntries(
              Object.entries(sels).map(([name, selector]) => {
                const node = document.querySelector(selector),
                  s = getComputedStyle(node);
                return [
                  name,
                  {
                    selector,
                    tag: node.tagName,
                    className: node.className,
                    inlineStyle: node.getAttribute("style"),
                    padding: s.padding,
                    borderRadius: s.borderRadius,
                    color: s.color,
                  },
                ];
              }),
            );
          });
          const inline = row.arms[arm];
          row[arm + "InlinePassed"] = [
            inline.inlineInput,
            inline.inlineButton,
          ].every(
            (x) =>
              x.padding === "17px" &&
              x.borderRadius === "23px" &&
              x.color === "rgb(42, 63, 84)",
          );
        }
        row.classDifferences = [];
        for (const target of ["classInput", "classLabel"])
          for (const property of ["padding", "borderRadius", "color"])
            if (
              row.arms.baseline[target][property] !==
              row.arms.legacy[target][property]
            )
              row.classDifferences.push({
                target,
                property,
                legacy: row.arms.legacy[target][property],
                migrated: row.arms.baseline[target][property],
              });
        row.status = row.classDifferences.length
          ? "Strict className override difference"
          : "Passed";
        results.push(row);
      }
    for (const p of Object.values(pages)) await p.close();
    await save("cascade-browser-progress", {
      browser: browser.version(),
      results,
    });
    console.log(host.host + " " + host.order + " " + results.length + " cells");
  }
  await save("cascade-browser-results", {
    browser: browser.version(),
    results,
    normalization:
      "No style values normalized. Class names are retained as source evidence, not directly compared because generated names are implementation-specific.",
    summary: {
      cells: results.length,
      classDifferenceCells: results.filter((r) => r.classDifferences.length)
        .length,
      inlineFailures: results.filter(
        (r) => !r.baselineInlinePassed || !r.legacyInlinePassed,
      ).length,
    },
  });
} finally {
  await browser.close();
}
