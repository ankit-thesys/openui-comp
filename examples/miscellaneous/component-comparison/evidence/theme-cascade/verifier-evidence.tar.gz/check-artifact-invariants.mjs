import fs from "node:fs/promises";
import path from "node:path";
import { createRequire } from "node:module";
import { execFileSync } from "node:child_process";
import { createHash } from "node:crypto";
const out = "/private/tmp/openui-theme-cascade-verification",
  req = createRequire(
    "/Users/ankitdas/.codex/worktrees/production-core-kits/openui/packages/react-ui/package.json",
  ),
  ts = req("typescript"),
  j = JSON.parse(
    await fs.readFile(
      out + "/fresh-baseline-runtime-correspondence.json",
      "utf8",
    ),
  );
const hash = (b) => createHash("sha256").update(b).digest("hex");
for (const x of j.relocatedVendorPayloads) {
  const extract = (archive, file) => {
    const src = execFileSync("tar", ["-xOf", archive, file], {
        encoding: "utf8",
      }),
      ast = ts.createSourceFile(file, src, ts.ScriptTarget.Latest, true);
    let object;
    function walk(n) {
      if (
        ts.isBinaryExpression(n) &&
        ts.isElementAccessExpression(n.left) &&
        n.left.expression.getText(ast) === "exports" &&
        n.left.argumentExpression.text === "default" &&
        ts.isObjectLiteralExpression(n.right)
      )
        object = n.right.getText(ast);
      ts.forEachChild(n, walk);
    }
    walk(ast);
    if (!object) throw Error("Missing palette object");
    return object;
  };
  const a = extract(j.frozenArchive, x.oldPath),
    b = extract(j.freshProductionBaselineArchive, x.newPath);
  x.paletteObjectByteIdentical = a === b;
  x.paletteObjectSha256 = hash(b);
  if (a !== b) throw Error("Theme data changed");
}
j.qualification =
  "Fresh isolated source builds use existing read-only workspace dependency links. Stock tsdown emits four bundled theme modules under build-path-dependent package-internal names. Four common consumer modules differ only in relative theme import paths; relocated theme modules differ in relative runtime-helper imports and region comments. Their complete theme object payloads are byte-identical (AST extraction hashes recorded), and the common runtime helper is unchanged. Raw archives are preserved without rewriting. Experimental archives are test evidence, not publication candidates.";
await fs.writeFile(
  out + "/fresh-baseline-runtime-correspondence.json",
  JSON.stringify(j, null, 2) + "\n",
);
async function walk(d) {
  let a = [];
  for (const x of await fs.readdir(d, { withFileTypes: true })) {
    if (x.isDirectory()) a.push(...(await walk(path.join(d, x.name))));
    else if (/\.d\.(mts|cts)$/.test(x.name)) a.push(path.join(d, x.name));
  }
  return a;
}
const base = out + "/source-candidates/base/packages/react-ui-core/dist",
  types = new Map();
for (const f of await walk(base))
  types.set(path.relative(base, f), hash(await fs.readFile(f)));
let results = [];
for (const c of JSON.parse(
  await fs.readFile(out + "/candidate-artifacts.json", "utf8"),
)) {
  const d = out + "/source-candidates/" + c.id + "/packages/react-ui-core/dist",
    different = [];
  const files = await walk(d);
  for (const f of files) {
    const rel = path.relative(d, f);
    if (types.get(rel) !== hash(await fs.readFile(f))) different.push(rel);
  }
  if (files.length !== types.size || different.length)
    throw Error("Public declaration drift " + c.id);
  results.push({
    id: c.id,
    publicTypeFiles: types.size,
    identicalPublicTypeFiles: files.length,
    differences: different,
    archiveSha256: c.archiveSha256,
  });
}
await fs.writeFile(
  out + "/candidate-type-invariants.json",
  JSON.stringify({ baselineTypeFiles: types.size, results }, null, 2) + "\n",
);
console.log(
  JSON.stringify({
    vendorPayloadObjectsIdentical: j.relocatedVendorPayloads.every(
      (x) => x.paletteObjectByteIdentical,
    ),
    candidateTypeInvariants: results.length,
    typeFilesPerCandidate: types.size,
  }),
);
