import "@openuidev/react-ui/styles/index.css";
import './probes.js';
import React from 'react';
import {createRoot} from 'react-dom/client';
import * as UI from '@openuidev/react-ui';
import {ModelSwitcher} from '@openuidev/react-ui';
import presets from './theme-presets.json';
import supplements from './theme-fixtures.json';
import componentInputs from './component-inputs.json';
import {Renderer} from '@openuidev/react-lang';
import {openuiChatLibrary} from '@openuidev/react-ui';
const root=createRoot(document.getElementById('root'));
window.fixtureObservations={actions:[],notices:[],errors:[]};
function Portals(){const [model,setModel]=React.useState('one');return <section data-case="portals"><UI.Select defaultValue="one"><UI.SelectTrigger aria-label="Fixture select"><UI.SelectValue/></UI.SelectTrigger><UI.SelectContent><UI.SelectItem value="one">First item</UI.SelectItem><UI.SelectItem value="two">Second item</UI.SelectItem></UI.SelectContent></UI.Select><UI.Calendar mode="single" defaultMonth={new Date(2026,2,15)} selected={new Date(2026,2,15)} startMonth={new Date(2020,0)} endMonth={new Date(2030,11)}/><ModelSwitcher models={[{id:'one',name:'First model',group:'Fixture'},{id:'two',name:'Second model',badge:'Test'}]} value={model} onValueChange={setModel}/><UI.TooltipWrapper tooltipHeading="Tooltip heading" tooltipContent="Tooltip body" delayDuration={0}><UI.Button aria-label="Fixture tooltip">Help</UI.Button></UI.TooltipWrapper></section>;}
function ThemeContextProbe({id}){const t=UI.useTheme();return <output hidden data-context={id} data-mode={t.mode} data-portal={t.portalThemeClassName}>{JSON.stringify(t.theme)}</output>;}
class Boundary extends React.Component{state={error:null};static getDerivedStateFromError(e){return {error:String(e)}}componentDidCatch(e){window.fixtureObservations.errors.push(String(e))}render(){return this.state.error?<div role="alert">{this.state.error}</div>:this.props.children}}
function CustomMarkdownPositions(){return <>{['first','middle','last'].map(position=><section key={position} data-case={'markdown-custom-'+position}><UI.MarkDownRenderer textMarkdown={'```js\nconst x = 1;\n```'} options={{components:{code:({children})=><>{position!=='first'&&<span data-before>Before</span>}<div className="openui-code-block-syntax-highlighter" data-custom-position={position} style={{padding:'1em',margin:'0.5em 0'}}>{children}</div>{position!=='last'&&<span data-after>After</span>}</>}}}/></section>)}</>}
function Components({reverse=false}) {
 const controls=<section data-case="controls"><UI.Button>Primary</UI.Button><UI.Input aria-label="Ordinary input" placeholder="Placeholder"/><UI.Input aria-label="Error input" hasError defaultValue="error"/><UI.Input aria-label="Disabled input" disabled defaultValue="disabled"/><UI.TextArea aria-label="Textarea" defaultValue="Text"/></section>;
 const cases=[<section key="slider" data-case="slider"><UI.SliderBlock variant="continuous" label="Amount" min={0} max={100} defaultValue={[20]}/><UI.SliderBlock variant="continuous" label="Invalid amount" min={0} max={100} defaultValue={[-10]}/><UI.SliderBlock variant="continuous" label="Disabled amount" disabled min={0} max={100} defaultValue={[20]}/><UI.SliderBlock variant="continuous" label="Disabled invalid amount" disabled min={0} max={100} defaultValue={[-10]}/><UI.SliderBlock variant="discrete" label="Range amount" min={0} max={100} step={10} defaultValue={[10,80]}/></section>,<section key="sources" data-case="sources"><UI.ListedSources sources={[{title:'Local source',sourceName:'Fixture',url:'#local',faviconUrl:''},{title:'No URL',sourceName:'Fixture',faviconUrl:''}]}/></section>,<section key="code" data-case="code"><UI.CodeBlock language="js" codeString="const answer = 42;"/></section>,<section key="markdown" data-case="markdown"><UI.MarkDownRenderer textMarkdown={'```js\nconst first = 1;\n```\n\nMiddle text.\n\n```js\nconst last = 2;\n```'}/></section>];
 return <>{reverse?cases.toReversed():cases}{controls}<CustomMarkdownPositions/><section data-case="public-overrides"><UI.Input aria-label="Inline override input" styles={{padding:17,borderRadius:23,color:"rgb(42, 63, 84)"}}/><UI.Input aria-label="Class override input" className="verifier-public-override"/><UI.Label className="verifier-public-override" disabled>Class override disabled label</UI.Label><UI.Button style={{padding:17,borderRadius:23,color:"rgb(42, 63, 84)"}}>Inline override button</UI.Button></section><UI.Label required>Required label</UI.Label><UI.Label disabled>Disabled label</UI.Label><Portals/></>;
}
function App({preset='cyberpunk',mode='light',reverse=false,withoutProvider=false,full=false,siblings=false,nested=false,caseSource=null,caseId='direct'}) {
 const selected=presets.presets.find(p=>p.id===preset);
 const themes=full?{lightTheme:supplements.fixtures.find(f=>f.preset===preset&&f.mode==='light').full,darkTheme:supplements.fixtures.find(f=>f.preset===preset&&f.mode==='dark').full}:{lightTheme:selected.lightTheme,darkTheme:selected.darkTheme};
 const body=caseSource?<Renderer key={caseId} response={caseSource} library={openuiChatLibrary} onAction={a=>window.fixtureObservations.actions.push(a)} onError={e=>window.fixtureObservations.notices.push(e)}/>:<Components reverse={reverse}/>;
 const content=<div id="theme-scope"><ThemeContextProbe id="primary"/><Boundary key={caseId}>{body}</Boundary>{nested&&<UI.ThemeProvider lightTheme={{textNeutralPrimary:'oklch(0.42 0.12 27 / 1)'}}><div data-nested><ThemeContextProbe id="nested"/><UI.Input aria-label="Nested input"/></div></UI.ThemeProvider>}</div>;
 const main=withoutProvider?content:<UI.ThemeProvider {...themes} mode={mode} cssSelector="#theme-scope">{content}</UI.ThemeProvider>;
 if(!siblings)return main;
 const other=presets.presets.find(p=>p.id===(preset==='cyberpunk'?'crimson-desert':'cyberpunk'));
 return <>{main}<UI.ThemeProvider lightTheme={other.lightTheme} darkTheme={other.darkTheme} mode={mode} cssSelector="#sibling-scope"><div id="sibling-scope"><ThemeContextProbe id="sibling"/><UI.Input aria-label="Sibling input"/><Portals/></div></UI.ThemeProvider></>;
}
window.fixture={componentInputs,render(config={}){window.fixtureConfig=config;window.fixtureObservations={actions:[],notices:[],errors:[]};root.render(<App {...config}/>);},unmount(){root.render(null);},exports:Object.keys(UI),presetHashes:presets.presets.map(p=>({id:p.id,hash:p.definitionHash})),supplementHashes:supplements.fixtures.map(f=>({preset:f.preset,mode:f.mode,hash:f.fixtureHash})),supplements:supplements.fixtures};
window.fixture.render();
