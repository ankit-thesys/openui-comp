import React from 'react';
import {SliderBlock,Input,Button,Label,Calendar,ListedSources,MarkDownRenderer,TextBlockView} from '@openuidev/react-ui-core';
export const valid = <>
<SliderBlock variant="continuous" label="Amount" min={0} max={100} defaultValue={[20]}/>
<SliderBlock variant="continuous" label="Invalid" disabled min={0} max={100} defaultValue={[-10]}/>
<SliderBlock variant="discrete" label="Range" min={0} max={100} step={10} defaultValue={[10,80]}/>
<Input styles={{padding:17,borderRadius:23,color:'rgb(42, 63, 84)'}}/>
<Button style={{padding:17}}>Override</Button><Label className="verifier-public-override" disabled>Label</Label>
<Calendar mode="single" defaultMonth={new Date(2026,2,15)} selected={new Date(2026,2,15)}/>
<ListedSources sources={[{title:'Local',sourceName:'Fixture',url:'#local',faviconUrl:''}]}/>
<MarkDownRenderer textMarkdown="Code" options={{components:{code:({children})=><div>{children}</div>}}}/>
<TextBlockView primary="234" secondary="Secondary" tertiary="Tertiary" variant="number-title-text" type="number" size="sm"/>
</>;
// This negative check ensures required fixture props are not hidden by any.
// @ts-expect-error SliderBlock's public variant is required.
export const missingVariant = <SliderBlock label="Invalid fixture" min={0} max={100}/>;
