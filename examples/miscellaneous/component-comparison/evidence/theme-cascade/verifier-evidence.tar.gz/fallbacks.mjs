import fs from "node:fs/promises";
const out = "/private/tmp/openui-theme-cascade-verification";
const fields = JSON.parse(
    await fs.readFile(out + "/token-ledger.json", "utf8"),
  ),
  refs = JSON.parse(
    await fs.readFile(out + "/consumed-variables.json", "utf8"),
  ),
  map = new Map(fields.filter((f) => f.variable).map((f) => [f.variable, f]));
const rows = [];
for (const r of refs) {
  let i = r.valueOffset + 4,
    depth = 1,
    quote = null,
    comma = -1;
  for (; i < r.value.length; i++) {
    const c = r.value[i];
    if (quote) {
      if (c === quote && r.value[i - 1] !== "\\") quote = null;
      continue;
    }
    if (c === '"' || c === "'") {
      quote = c;
      continue;
    }
    if (c === "(") depth++;
    if (c === ")") {
      depth--;
      if (!depth) break;
    }
    if (c === "," && depth === 1 && comma < 0) comma = i;
  }
  const fallback = comma < 0 ? null : r.value.slice(comma + 1, i).trim(),
    field = map.get(r.variable),
    expected = field?.defaultLight;
  const zero = (v) =>
    /^[+-]?(?:0+(?:\.0*)?|\.0+)(?:px|rem|em|%)?$/.test(v ?? "");
  rows.push({
    ...r,
    fallback,
    field: field?.field ?? null,
    expected: expected ?? null,
    comparison: !field
      ? "Internal/non-theme variable"
      : fallback === null
        ? "No fallback"
        : fallback === expected
          ? "Exact light default"
          : zero(fallback) && zero(expected)
            ? "Equivalent zero spelling"
            : "Requires review",
  });
}
await fs.writeFile(
  out + "/fallback-comparison.json",
  JSON.stringify(rows, null, 2) + "\n",
);
const count = {};
for (const r of rows) count[r.comparison] = (count[r.comparison] ?? 0) + 1;
console.log(
  JSON.stringify({
    counts: count,
    review: rows
      .filter((r) => r.comparison === "Requires review")
      .map((r) => ({
        file: r.file,
        line: r.line,
        variable: r.variable,
        fallback: r.fallback,
        expected: r.expected,
      })),
  }),
);
