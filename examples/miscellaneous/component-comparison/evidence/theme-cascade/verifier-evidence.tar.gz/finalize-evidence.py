import pathlib,json,hashlib,difflib,tarfile,subprocess,datetime,collections
P=pathlib.Path('/private/tmp/openui-theme-cascade-verification'); R=pathlib.Path('/Users/ankitdas/.codex/worktrees/production-core-kits/openui')
def load(n): return json.loads((P/n).read_text())
def save(n,d): (P/n).write_text(json.dumps(d,indent=2)+'\n')
def sha(b):return hashlib.sha256(b).hexdigest()
# Preserve source/markup evidence for the two unrendered inherited selectors.
paths=['packages/react-ui-core/src/components/Charts/shared/core/PortalTooltip/portalTooltip.styles.ts','packages/react-ui-core/src/components/Charts/shared/core/PortalTooltip/ChartTooltip.tsx','packages/react-ui/src/components/Charts/shared/core/PortalTooltip/portalTooltip.scss','packages/react-ui/src/components/Charts/shared/core/PortalTooltip/ChartTooltip.tsx']
evidence=[]
for f in paths:
 s=(R/f).read_text();evidence.append({'file':f,'sha256':sha(s.encode()),'lines':[{'line':i,'source':s1} for i,s1 in enumerate(s.splitlines(),1) if 'label-heavy' in s1 or 'text-label-xs-heavy' in s1 or 'tooltip-label`' in s1 or 'label, xs, heavy' in s1]})
save('inherited-unreachable-token-gap.json',{'status':'Not covered: inherited inactive selector','fields':['textLabelXsHeavy','textLabelXsHeavyLetterSpacing'],'selector':'.openui-chart-tooltip-label-heavy','reason':'Both legacy and migrated styles define the heavy-label selector, but their ChartTooltip markup emits only the ordinary tooltip-label class. Whole Charts source search found no markup producer for the heavy class. No synthetic class or DOM mutation was added to manufacture coverage.','evidence':evidence,'coverage':'122/124 statically CSS-referenced string tokens verified through actual consumers in each of four full theme/mode fixtures. The two remaining references are not green.'})
# Merge only valid V1 probes and corrected V2/V3 additions.
proofsets={}
for preset in ['cyberpunk','crimson-desert']:
 for mode in ['light','dark']:
  key=f'{preset}-{mode}';a=load('token-'+key+'.json');b=load('token-v2-'+key+'.json');c=load('token-v3-'+key+'.json')
  valid=[x for x in a['proofs'] if not(x['caseId'].startswith('direct-') and 'openui-slider' in x.get('className',''))]
  merged=[]
  for name,proofs in [('token-'+key+'.json',valid),('token-v2-'+key+'.json',b['proofs']),('token-v3-'+key+'.json',c['proofs'])]:
   merged += [dict(x,evidenceFile=name) for x in proofs]
  assert len({x['variable'] for x in merged})==122
  proofsets[key]=merged
save('token-wiring-final.json',{'coveragePerFixture':122,'staticReferencedStrings':124,'fixtures':proofsets,'scope':'Representative actual consumer per token; not an assertion that every consumer of the token was exercised. All negative controls remove one provider mapping and restore it.'})
extra=load('theme-extra-results.json');ledger=load('token-ledger.json')
for x in ledger:
 x['allConsumerBrowserCoverage']='Not covered exhaustively; representative coverage only'
 if x['type']=='string':
  proofs={k:[y for y in v if y['field']==x['field']] for k,v in proofsets.items()}
  if all(proofs.values()): x['browserStatus']='Passed: representative actual-consumer wiring in four full theme/mode fixtures';x['browserEvidence']={k:[{'file':y['evidenceFile'],'caseId':y['caseId'],'property':y['property'],'selector':y['selector']} for y in v] for k,v in proofs.items()}
  elif x['field'] in ['textLabelXsHeavy','textLabelXsHeavyLetterSpacing']:x['browserStatus']='Not covered: inherited inactive heavy tooltip selector';x['browserEvidence']=['inherited-unreachable-token-gap.json']
  else:x['browserStatus']='Not applicable to CSS-consumer wiring: no direct CSS reference in scoped packages' if not x['cssConsumers'] else 'Not covered'
  emitted=[r for r in extra['records'] if r['kind']=='full-variable-emission-and-nesting' and any(v['field']==x['field'] and v['actual']==v['expected'] for v in r['vars'])]
  x['providerEmission']='Passed in four full fixtures' if len(emitted)==4 else 'Not covered / unsupported inherited field'
 else:
  tests=[r for r in extra['records'] if r['kind']=='palette-context-negative' and r['field']==x['field']]
  x['browserStatus']='Passed: actual chart mark paint/context negative control in four fixtures' if len(tests)==4 and all(r['pass'] for r in tests) else 'Not covered completely: context/legend observations retained; mark-paint probe did not establish required evidence'
  x['browserEvidence']=['theme-extra-results.json']
save('token-ledger.json',ledger)
# Combined declarations are identical; no production API changes.
a=P/'source-candidates/base/packages/react-ui-core/dist';b=P/'source-candidates/combined/packages/react-ui-core/dist'
afiles={str(f.relative_to(a)):sha(f.read_bytes()) for f in a.rglob('*') if f.is_file() and (f.name.endswith('.d.mts') or f.name.endswith('.d.cts'))}
bfiles={str(f.relative_to(b)):sha(f.read_bytes()) for f in b.rglob('*') if f.is_file() and (f.name.endswith('.d.mts') or f.name.endswith('.d.cts'))}
assert afiles==bfiles and len(afiles)==440
save('combined-type-invariants.json',{'files':440,'identical':440,'differences':[],'hashes':afiles})
# Six-removal source diff only.
safe={'08','09','10','12','13','16'}; manifest=load('counterfactual-manifest.json'); patches=[];files={x['file'] for x in manifest if x['id'] in safe}; originals={}
for f in sorted(files):
 old=(R/f).read_text();new=(P/'source-candidates/combined'/f).read_text();assert old.replace(' !important','').count('!important')<=old.count('!important')
 assert old.count('!important')-new.count('!important')==sum(x['file']==f and x['id'] in safe for x in manifest)
 # Confirm candidate is exactly the sum of already isolated literal removals.
 lines=old.splitlines(keepends=True)
 for x in manifest:
  if x['file']==f and x['id'] in safe: lines[x['line']-1]=lines[x['line']-1].replace(' !important','',1)
 assert ''.join(lines)==new
 originals[f]={'originalSha256':sha(old.encode()),'candidateSha256':sha(new.encode())}
 patches += list(difflib.unified_diff(old.splitlines(keepends=True),new.splitlines(keepends=True),fromfile='a/'+f,tofile='b/'+f))
(P/'safe-important-removals.patch').write_text(''.join(patches))
reasons={'01':'Third-party highlighter inline .5em margins win without important; observed 0px -> 6.5px.','02':'Third-party inline 1em padding wins without important; observed 25px -> 16px.','03':'Nested CodeBlock important margin shorthand wins over ordinary markdown top margin; 8px -> 0px.','04':'Full custom typography plus supported custom code renderer makes .5em bottom margin 8.5px instead of 8px; partial discovery alone was insufficient.','05':'Supported custom first-child code renderer loses zero top margin to generic important 8px declaration.','06':'Actual last-child highlighter loses zero bottom margin to generic important 8px declaration.','07':'Input hover selector wins over Slider error selector without important; error border changes from danger to interactive.','11':'Mobile Carousel competing width wins; observed 180px -> 248px at 390px viewport.','14':'Sunk Carousel background wins over ordinary transparent Sources background.','15':'Retained important base background beats ordinary hovered background.'}
discovery={x['id'][-2:]:x for x in load('important-v2-discovery-results.json')['results']};discovery.update({x['id'][-2:]:x for x in load('important-v3-discovery-results.json')['results']});extension={x['id'][-2:]:x for x in load('important-v3-extension-results.json')['results']}
rows=[]
for x in manifest:
 i=x['id']; d=discovery[i];e=extension.get(i);cells=d['cells']+(e['cells'] if e else 0);different=d['different']+(e['different'] if e else 0)
 row={k:v for k,v in x.items() if k not in ['status','decision','browserStatus']};row.update({'decision':'Eligible for removal within recorded coverage' if i in safe else 'Retain','status':'Passed removal-only comparison' if i in safe else 'Removal changes observed styling','individualCells':cells,'differentCells':different,'combinedCells':240 if i in safe else None,'combinedDifferences':0 if i in safe else None,'reason':'No replacement; ordinary existing rule wins with unchanged observed computed styles, geometry and interaction behavior.' if i in safe else reasons[i],'evidence':['important-v3-discovery-results.json' if i in ['08','09','10'] else 'important-v2-discovery-results.json']+(['important-v3-extension-results.json'] if e else [])})
 if i not in safe:
  witness=next((z for z in d['cases'] if z['differences']),None) or next(z for z in e['cases'] if z['differences']);row['firstFailureWitness']=witness
 rows.append(row)
save('important-decisions.json',rows)
save('safe-removal-allowlist.json',{'baselineHead':load('source-provenance.json')['head'],'scope':'Six literal important removals only, two files; verification evidence, not a production change or global parity approval. Named-import compatibility guards must be checked in named-guards-results.json.','ids':sorted(safe),'files':originals,'declarations':[r for r in rows if r['id'] in safe],'combinedArtifact':load('combined-artifact.json'),'publicTypes':'combined-type-invariants.json','patch':'safe-important-removals.patch','patchSha256':sha((P/'safe-important-removals.patch').read_bytes())})
# No production mutation.
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip();dirty=subprocess.check_output(['git','status','--porcelain'],cwd=R,text=True);assert head==load('source-provenance.json')['head'] and dirty==''
save('final-production-state.json',{'head':head,'dirty':dirty,'verifiedUTC':datetime.datetime.now(datetime.timezone.utc).isoformat(),'productionEdited':False})
print('Final ledger, source evidence, declaration table, six-removal patch and combined type hashes prepared.')
