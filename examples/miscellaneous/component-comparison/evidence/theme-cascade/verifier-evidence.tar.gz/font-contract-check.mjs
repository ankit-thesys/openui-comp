import fs from "node:fs/promises";
import { createRequire } from "node:module";
import assert from "node:assert/strict";
const out = "/private/tmp/openui-theme-cascade-verification",
  req = createRequire(out + "/consumer/package.json"),
  UI = req("@openuidev/react-ui-core");
const presets = JSON.parse(
  await fs.readFile(out + "/theme-presets.json", "utf8"),
);
let rows = [];
for (const p of presets.presets.filter((x) => x.id !== "default"))
  for (const mode of ["light", "dark"]) {
    const override = p[mode + "Theme"],
      base = mode === "dark" ? UI.defaultDarkTheme : UI.defaultLightTheme;
    const returned = UI.createTheme(override),
      resolved = { ...base, ...returned };
    assert.equal(returned, override);
    assert.equal(resolved.textBodyDefault, base.textBodyDefault);
    assert.notEqual(resolved.fontBody, base.fontBody);
    assert.equal(resolved.textLabelDefault, override.textLabelDefault);
    assert.equal(resolved.textLabelDefaultHeavy, base.textLabelDefaultHeavy);
    rows.push({
      preset: p.id,
      mode,
      fontBody: resolved.fontBody,
      textBodyDefault: resolved.textBodyDefault,
      textLabelDefault: resolved.textLabelDefault,
      textLabelDefaultHeavy: resolved.textLabelDefaultHeavy,
      assertions: 4,
      status:
        "Passed static public-API check; computed browser fonts Not covered",
    });
  }
await fs.writeFile(
  out + "/font-contract-results.json",
  JSON.stringify(rows, null, 2) + "\n",
);
console.log(
  JSON.stringify({
    cases: rows.length,
    assertions: rows.length * 4,
    browser: false,
  }),
);
