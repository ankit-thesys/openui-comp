import fs from "node:fs/promises";
import path from "node:path";
import { createHash } from "node:crypto";
import { execFileSync } from "node:child_process";
const repo = "/Users/ankitdas/.codex/worktrees/production-core-kits/openui",
  out = "/private/tmp/openui-theme-cascade-verification";
const paths = execFileSync(
    "git",
    [
      "ls-tree",
      "-r",
      "--name-only",
      "57ea72e2892df7fdd551c668d4480a0267f90a09",
      "--",
      "packages/react-ui-core/src",
      "packages/kits/src",
    ],
    { cwd: repo, encoding: "utf8" },
  )
    .trim()
    .split("\n")
    .sort(),
  rows = [];
for (const file of paths) {
  const bytes = await fs.readFile(repo + "/" + file);
  rows.push({
    path: file,
    sha256: createHash("sha256").update(bytes).digest("hex"),
  });
}
rows.sort((a, b) => a.path.localeCompare(b.path));
const digest = createHash("sha256").update(JSON.stringify(rows)).digest("hex");
await fs.writeFile(
  out + "/full-source-provenance.json",
  JSON.stringify(
    {
      head: "57ea72e2892df7fdd551c668d4480a0267f90a09",
      files: rows.length,
      sort: "path.localeCompare",
      sha256: digest,
      matchesWorkerHandoff:
        digest ===
        "4fa90d60e1f3206daf0cab0310eacb3781ba9a950eb40fa6ed10b5f8a7690243",
      rows,
    },
    null,
    2,
  ) + "\n",
);
console.log(
  JSON.stringify({
    files: rows.length,
    sha256: digest,
    matchesWorkerHandoff:
      digest ===
      "4fa90d60e1f3206daf0cab0310eacb3781ba9a950eb40fa6ed10b5f8a7690243",
  }),
);
