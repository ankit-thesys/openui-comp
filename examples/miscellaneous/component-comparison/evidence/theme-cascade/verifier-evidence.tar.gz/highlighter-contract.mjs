import fs from "node:fs/promises";
import { createRequire } from "node:module";
import { createHash } from "node:crypto";
import assert from "node:assert/strict";
const out = "/private/tmp/openui-theme-cascade-verification",
  req = createRequire(out + "/consumer/package.json"),
  React = req("react"),
  { renderToStaticMarkup } = req("react-dom/server"),
  UI = req("@openuidev/react-ui-core");
const hash = (b) => createHash("sha256").update(b).digest("hex");
const code = renderToStaticMarkup(
  React.createElement(UI.CodeBlock, {
    language: "js",
    codeString: "const a = 1;",
  }),
);
const markdown = renderToStaticMarkup(
  React.createElement(UI.MarkDownRenderer, {
    textMarkdown: "Before.\n\n```js\nconst a = 1;\n```\n\nAfter.",
  }),
);
await fs.writeFile(out + "/codeblock-markup.html", code);
await fs.writeFile(out + "/markdown-markup.html", markdown);
const rows = [];
for (const [name, html] of [
  ["CodeBlock", code],
  ["Markdown", markdown],
]) {
  const tag = html.match(
    /<div\b[^>]*class="[^"]*openui-code-block-syntax-highlighter[^>]*>/,
  )?.[0];
  assert.ok(tag);
  const inline = tag.match(/style="([^"]*)"/)?.[1];
  assert.ok(/padding:1em/.test(inline));
  assert.ok(/margin:(?:0?\.5)em 0/.test(inline));
  assert.ok(html.indexOf("<button") < html.indexOf(tag));
  rows.push({
    component: name,
    tag,
    inlineStyle: inline,
    inlinePadding: "1em",
    inlineMargin: ".5em 0",
    copyButtonPrecedesSyntax: true,
    markupSha256: hash(html),
    browserStatus: "Not covered",
    scope: "Static markup inspection only; no SSR support acceptance",
  });
}
await fs.writeFile(
  out + "/highlighter-contract-results.json",
  JSON.stringify(rows, null, 2) + "\n",
);
console.log(
  JSON.stringify({
    cases: rows.length,
    inlinePaddingMarginConfirmed: true,
    buttonPredecessorConfirmed: true,
    browser: false,
  }),
);
