import fs from "node:fs/promises";
import { gzipSync } from "node:zlib";
import {
  chromium,
  executablePath,
  out,
  hosts,
  schemes,
  fullSchemes,
  openPage,
  render,
  settle,
  save,
} from "./browser-common.mjs";
const buildPrefix = "v2-";
const stage = process.argv[2] ?? "baseline";
const families = {
  code: [1],
  markdown: [2, 3, 4, 5, 6],
  slider: [7, 8, 9, 10],
  sources: [11, 12, 13, 14, 15, 16],
};
const allSchemes = [...schemes, ...fullSchemes];
const entries = [
  "baseline",
  ...Array.from(
    { length: 16 },
    (_, i) => "remove-" + String(i + 1).padStart(2, "0"),
  ),
];
const properties = [
  "display",
  "position",
  "box-sizing",
  "width",
  "height",
  "padding-top",
  "padding-right",
  "padding-bottom",
  "padding-left",
  "margin-top",
  "margin-right",
  "margin-bottom",
  "margin-left",
  "border-top-color",
  "border-top-width",
  "border-top-style",
  "border-right-width",
  "border-bottom-width",
  "border-left-width",
  "border-top-left-radius",
  "border-top-right-radius",
  "border-bottom-left-radius",
  "border-bottom-right-radius",
  "background-color",
  "color",
  "font",
  "font-variation-settings",
  "letter-spacing",
  "text-align",
  "cursor",
  "opacity",
  "box-shadow",
  "outline",
  "overflow",
];
const selectors = {
  slider: [
    '[data-case="slider"] input',
    '[data-case="slider"] [role="slider"]',
  ],
  sources: ['[data-case="sources"] .openui-listed-sources-item-container'],
  code: [
    '[data-case="code"] .openui-code-block-syntax-highlighter',
    '[data-case="code"] .openui-code-block-copy-button',
  ],
  markdown: [
    '[data-case="markdown"] .openui-code-block-syntax-highlighter',
    '[data-case^="markdown-custom-"] .openui-code-block-syntax-highlighter',
  ],
};
const key = (c) => JSON.stringify(c);
let baseline = {};
try {
  baseline = JSON.parse(
    await fs.readFile(out + "/important-v3-baseline.json", "utf8"),
  ).snapshots;
} catch {}
async function snapshot(page, family) {
  return await page.evaluate(
    ({ sels, properties }) =>
      sels.flatMap((selector) =>
        [...document.querySelectorAll(selector)].map((node, index) => {
          const s = getComputedStyle(node),
            r = node.getBoundingClientRect();
          return {
            selector,
            index,
            style: Object.fromEntries(
              properties.map((p) => [p, s.getPropertyValue(p)]),
            ),
            rect: { x: r.x, y: r.y, width: r.width, height: r.height },
            value: node.value ?? null,
            ariaValueNow: node.getAttribute("aria-valuenow"),
            disabled: node.disabled ?? false,
          };
        }),
      ),
    { sels: selectors[family], properties },
  );
}
async function settleSliderTransitions(page) {
  await settle(page);
  await page.evaluate(async () => {
    const transitions = [...document.querySelectorAll('[data-case="slider"] *')]
      .flatMap((node) => node.getAnimations())
      .filter((animation) => animation.constructor.name === "CSSTransition");
    await Promise.all(
      transitions.map((animation) => animation.finished.catch(() => {})),
    );
  });
  await settle(page);
}
async function measure(page, config, only) {
  await render(page, config);
  const familiesToRead = only ? [only] : Object.keys(families),
    result = {};
  for (const f of familiesToRead) result[f] = { rest: await snapshot(page, f) };
  if (familiesToRead.includes("sources")) {
    for (const [name, selector] of [
      [
        "hover-url",
        '[data-case="sources"] .openui-listed-sources-item-container--has-url',
      ],
      [
        "hover-no-url",
        '[data-case="sources"] .openui-listed-sources-item-container:not(.openui-listed-sources-item-container--has-url)',
      ],
    ]) {
      await page.locator(selector).hover();
      await settle(page, 25);
      result.sources[name] = await snapshot(page, "sources");
    }
    await page.mouse.move(-10, -10);
  }
  if (familiesToRead.includes("slider")) {
    for (const [name, index] of [
      ["focus-normal", 0],
      ["focus-error", 1],
    ]) {
      await page.locator('[data-case="slider"] input').nth(index).focus();
      await settleSliderTransitions(page);
      result.slider[name] = await snapshot(page, "slider");
    }
    await page.evaluate(() => document.activeElement?.blur());
    for (const [name, index] of [
      ["hover-normal", 0],
      ["hover-error", 1],
      ["hover-disabled", 2],
      ["hover-disabled-error", 3],
    ]) {
      await page.locator('[data-case="slider"] input').nth(index).hover();
      await settleSliderTransitions(page);
      result.slider[name] = await snapshot(page, "slider");
    }
    await page.mouse.move(-10, -10);
  }
  if (familiesToRead.includes("code")) {
    await page.locator('[data-case="code"] .openui-code-block-wrapper').hover();
    await settle(page, 220);
    result.code.hover = await snapshot(page, "code");
    await page.mouse.move(-10, -10);
  }
  return result;
}
function differences(a, b, path = "") {
  const d = [];
  if (
    typeof a !== typeof b ||
    a === null ||
    b === null ||
    typeof a !== "object"
  ) {
    if (a !== b) d.push({ path, baseline: a, candidate: b });
    return d;
  }
  for (const k of new Set([...Object.keys(a), ...Object.keys(b)]))
    d.push(...differences(a[k], b[k], path ? path + "." + k : k));
  return d;
}
const browser = await chromium.launch({ executablePath, headless: true });
const snapshots = {},
  results = [],
  artifacts = JSON.parse(
    await fs.readFile(out + "/candidate-artifacts.json", "utf8"),
  );
let work;
if (stage === "baseline") work = ["baseline"];
else if (stage === "discovery") work = entries.slice(1);
else {
  const prior = JSON.parse(
    await fs.readFile(out + "/important-v3-discovery-results.json", "utf8"),
  );
  work = prior.results
    .filter((r) => r.status === "No differences in discovery")
    .map((r) => r.id);
}
if (process.env.VERIFICATION_IDS)
  work = process.env.VERIFICATION_IDS.split(",");
try {
  for (const id of work) {
    const number = Number(id.slice(-2)),
      family =
        id === "baseline"
          ? (process.env.VERIFICATION_FAMILY ?? null)
          : Object.keys(families).find((k) => families[k].includes(number));
    const cases = [],
      seen = new Set(),
      raw = {};
    for (const host of hosts) {
      const page = await openPage(
        browser,
        buildPrefix + id,
        host.host,
        host.order,
      );
      for (const width of [390, 1280]) {
        await page.setViewportSize({ width, height: 1000 });
        for (const scheme of stage === "discovery" ? schemes : allSchemes)
          for (const reverse of stage === "discovery"
            ? [false]
            : [false, true]) {
            if (stage === "extension" && !scheme.full && !reverse) continue;
            const config = { ...scheme, reverse },
              cell = { ...host, width, ...config },
              k = key(cell);
            try {
              const actual = await measure(page, config, family);
              if (id === "baseline") {
                snapshots[k] = actual;
                cases.push({
                  cell,
                  status: "Captured baseline",
                  pageErrors: [...page.verificationErrors],
                });
              } else {
                if (!baseline[k])
                  throw Error("Missing exact baseline cell " + k);
                const d = differences(baseline[k][family], actual[family]);
                raw[k] = actual[family];
                cases.push({
                  cell,
                  status: d.length ? "Different" : "Equal",
                  differences: d,
                  pageErrors: [...page.verificationErrors],
                });
              }
            } catch (e) {
              cases.push({
                cell,
                status: "Check failed",
                error: String(e),
                pageErrors: [...page.verificationErrors],
              });
            }
            seen.add(k);
          }
        await save("important-v3-browser-progress", {
          stage,
          id,
          family,
          cases: cases.length,
          failed: cases.filter(
            (c) => !["Captured baseline", "Equal"].includes(c.status),
          ).length,
          completedArtifacts: results.map((r) => ({
            id: r.id,
            status: r.status,
          })),
        });
      }
      await page.close();
      console.log(
        stage +
          " " +
          id +
          " " +
          host.host +
          " " +
          host.order +
          " " +
          cases.length +
          " cells",
      );
    }
    if (id === "baseline") {
      const prior = JSON.parse(
        await fs.readFile(out + "/important-v2-baseline.json", "utf8"),
      );
      const finalSnapshots = prior.snapshots;
      for (const [k, value] of Object.entries(snapshots))
        Object.assign(finalSnapshots[k], value);
      await save("important-v3-baseline", {
        browser: browser.version(),
        properties,
        selectors,
        snapshots: finalSnapshots,
        cases,
        sourceReuse:
          "Non-Slider groups reused from V2, Slider groups fully remeasured with settled blur/hover transitions",
        normalizations:
          "No computed values or geometry normalized. Generated class names are not comparison targets; source and artifact hashes retain those changes.",
      });
      baseline = finalSnapshots;
    } else {
      const status = cases.some((c) => c.status === "Check failed")
        ? "Coverage failure"
        : cases.some((c) => c.status === "Different")
          ? "Removal changes styling"
          : stage === "discovery"
            ? "No differences in discovery"
            : "No differences in extended matrix";
      const r = {
        id,
        family,
        status,
        cells: cases.length,
        equal: cases.filter((c) => c.status === "Equal").length,
        different: cases.filter((c) => c.status === "Different").length,
        artifact: artifacts.find((a) => a.id === id),
        cases,
      };
      results.push(r);
      await fs.writeFile(
        out + "/important-" + stage + "-" + id + "-raw.json.gz",
        gzipSync(JSON.stringify(raw)),
      );
      await save("important-v3-" + stage + "-results", {
        browser: browser.version(),
        stage,
        results,
      });
      console.log(id + " " + status + " " + r.equal + "/" + r.cells);
    }
  }
} finally {
  await browser.close();
}
