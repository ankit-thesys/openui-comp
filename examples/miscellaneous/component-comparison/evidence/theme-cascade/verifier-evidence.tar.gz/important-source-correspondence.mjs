import fs from "node:fs/promises";
import assert from "node:assert/strict";
const out = "/private/tmp/openui-theme-cascade-verification",
  manifest = JSON.parse(
    await fs.readFile(out + "/counterfactual-manifest.json", "utf8"),
  ),
  legacy = JSON.parse(
    await fs.readFile(out + "/expanded-legacy-inventory.json", "utf8"),
  );
const normalize = (s) =>
  s
    .replace(/\s*!important\s*$/, "")
    .replace(/var\((--[\w-]+),.*\)$/, "var($1)")
    .replace(/\s+/g, " ")
    .trim();
let rows = [];
for (const m of manifest) {
  const folder = m.file.split("/")[4],
    scss = legacy.filter((f) => f.file.includes("/" + folder + "/"));
  let matches = [];
  const prop = m.property.replace(/[A-Z]/g, (s) => "-" + s.toLowerCase());
  for (const f of scss)
    for (const r of f.rules ?? [])
      for (const d of r.declarations ?? [])
        if (
          d.important &&
          d.property === prop &&
          normalize(d.value) === normalize(m.value)
        )
          matches.push({
            legacyFile: f.file,
            legacySelector: r.selector,
            legacyProperty: d.property,
            legacyValue: d.value,
            ancestors: r.ancestors,
          });
  assert.equal(matches.length, 1, JSON.stringify({ id: m.id, prop, matches }));
  rows.push({
    id: m.id,
    productionFile: m.file,
    productionLine: m.line,
    property: prop,
    productionValue: m.value,
    ...matches[0],
    status: "Passed static inherited declaration correspondence",
    runtimeRemoval: "Not covered",
    approved: false,
  });
}
await fs.writeFile(
  out + "/important-source-correspondence.json",
  JSON.stringify(rows, null, 2) + "\n",
);
console.log(
  JSON.stringify({
    cases: rows.length,
    uniqueLegacyMatches: rows.length,
    removalsApproved: 0,
  }),
);
