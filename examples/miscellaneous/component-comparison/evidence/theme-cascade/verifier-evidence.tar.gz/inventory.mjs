import fs from "node:fs/promises";
import path from "node:path";
import { createRequire } from "node:module";
import { createHash } from "node:crypto";
import { execFileSync } from "node:child_process";
const repo = "/Users/ankitdas/.codex/worktrees/production-core-kits/openui",
  out = "/private/tmp/openui-theme-cascade-verification";
const tools = createRequire(repo + "/packages/react-ui/package.json");
const ts = tools("typescript");
const installed = createRequire(
  "/private/tmp/openui-chat16-independent-verification/consumer-border/package.json",
);
const core = installed("@openuidev/react-ui-core");
const legacy = repo + "/packages/react-ui/src";
const sourceRoots = ["packages/react-ui-core/src", "packages/kits/src"];
const hash = (b) => createHash("sha256").update(b).digest("hex");
const kebab = (s) =>
  s
    .replace(/([a-z])([A-Z])/g, "$1-$2")
    .replace(/([A-Z])([A-Z])/g, "$1-$2")
    .replace(/([a-z])(\d)/g, "$1-$2")
    .toLowerCase();
const files = [];
for (const r of sourceRoots) files.push(...(await walk(repo + "/" + r)));
const sources = new Map();
for (const f of files.filter((x) => /\.(ts|tsx)$/.test(x))) {
  const text = await fs.readFile(f, "utf8");
  sources.set(f, {
    text,
    ast: ts.createSourceFile(
      f,
      text,
      ts.ScriptTarget.Latest,
      true,
      f.endsWith("tsx") ? ts.ScriptKind.TSX : ts.ScriptKind.TS,
    ),
  });
}
const themeTypes = sources.get(
  repo + "/packages/react-ui-core/src/components/ThemeProvider/types.ts",
);
const fieldRows = [];
const palettes = [];
for (const s of themeTypes.ast.statements) {
  if (ts.isInterfaceDeclaration(s) && s.name.text !== "Theme")
    for (const p of s.members)
      if (ts.isPropertySignature(p))
        fieldRows.push({
          field: p.name.getText(themeTypes.ast),
          group: s.name.text,
          type: p.type?.getText(themeTypes.ast),
          line:
            themeTypes.ast.getLineAndCharacterOfPosition(p.getStart()).line + 1,
        });
  if (ts.isVariableStatement(s))
    for (const d of s.declarationList.declarations)
      if (d.name.getText() === "CHART_PALETTE_KEYS") {
        const literal = d.initializer.expression ?? d.initializer;
        for (const e of literal.elements) palettes.push(e.text);
      }
}
for (const field of palettes)
  fieldRows.push({
    field,
    group: "ChartColorPalette",
    type: "string[]",
    line: 8,
  });
const fields = new Map(
  fieldRows.map((f) => [
    f.field,
    {
      ...f,
      variable: f.type === "string[]" ? null : "--openui-" + kebab(f.field),
      defaultLight: core.defaultLightTheme[f.field] ?? null,
      defaultDark: core.defaultDarkTheme[f.field] ?? null,
      cssConsumers: [],
      contextConsumers: [],
      browserStatus: "Not covered",
    },
  ]),
);
const byVariable = new Map(
  [...fields.values()].filter((f) => f.variable).map((f) => [f.variable, f]),
);
const variableRefs = [],
  selectors = [],
  important = [],
  styleModules = [];
for (const [file, { text, ast }] of sources) {
  let styleDefinitions = 0;
  const rel = path.relative(repo, file);
  function location(n) {
    const p = ast.getLineAndCharacterOfPosition(n.getStart());
    return { file: rel, line: p.line + 1, column: p.character + 1 };
  }
  function chain(n) {
    const names = [];
    let p = n.parent;
    while (p) {
      if (ts.isPropertyAssignment(p))
        names.unshift(p.name.getText(ast).replace(/^['"]|['"]$/g, ""));
      if (ts.isVariableDeclaration(p)) {
        names.unshift(p.name.getText(ast));
        break;
      }
      p = p.parent;
    }
    return names;
  }
  function visit(n) {
    if (
      (ts.isCallExpression(n) &&
        ["css", "keyframes"].includes(n.expression.getText(ast))) ||
      (ts.isTaggedTemplateExpression(n) &&
        ["css", "keyframes"].includes(n.tag.getText(ast)))
    )
      styleDefinitions++;
    if (
      ts.isStringLiteral(n) ||
      ts.isNoSubstitutionTemplateLiteral(n) ||
      ts.isTemplateHead(n) ||
      ts.isTemplateMiddle(n) ||
      ts.isTemplateTail(n)
    ) {
      const value = n.text ?? "";
      const isProperty =
        ts.isPropertyAssignment(n.parent) && n.parent.name === n;
      if (
        isProperty &&
        (/[&:@>\[.#]/.test(value) ||
          (value.includes(" ") &&
            n.parent.initializer &&
            ts.isObjectLiteralExpression(n.parent.initializer)))
      )
        selectors.push({
          ...location(n),
          selector: value,
          path: chain(n.parent),
          classification:
            ":where/scoping/order requires full source comparison",
          where: value.includes(":where("),
        });
      for (const match of value.matchAll(/var\(\s*(--[\w-]+)/g)) {
        const row = {
          ...location(n),
          variable: match[1],
          valueOffset: match.index,
          property: ts.isPropertyAssignment(n.parent)
            ? n.parent.name.getText(ast).replace(/^['"]|['"]$/g, "")
            : null,
          value,
          path: chain(n),
        };
        variableRefs.push(row);
        byVariable.get(match[1])?.cssConsumers.push(row);
      }
      if (value.includes("!important"))
        important.push({
          ...location(n),
          value,
          path: chain(n),
          property: ts.isPropertyAssignment(n.parent)
            ? n.parent.name.getText(ast).replace(/^['"]|['"]$/g, "")
            : null,
          status: "Not tested",
          decision: "Pending isolated removal experiment",
        });
    }
    if (
      ts.isPropertyAccessExpression(n) &&
      ["theme", "activeTheme", "resolvedTheme"].includes(
        n.expression.getText(ast),
      )
    ) {
      const f = fields.get(n.name.text);
      if (f)
        f.contextConsumers.push({ ...location(n), expression: n.getText(ast) });
    }
    if (
      ts.isElementAccessExpression(n) &&
      n.expression.getText(ast) === "theme"
    ) {
      for (const f of fields.values())
        if (f.group === "ChartColorPalette")
          f.contextConsumers.push({
            ...location(n),
            expression: n.getText(ast),
            dynamic: true,
          });
    }
    ts.forEachChild(n, visit);
  }
  visit(ast);
  if (
    styleDefinitions ||
    (/style/i.test(path.basename(file)) && /goober/.test(text))
  ) {
    const owner = rel.startsWith("packages/kits") ? "kits" : "core";
    const prefix =
      owner === "core"
        ? repo + "/packages/react-ui-core/src/components/"
        : repo + "/packages/kits/src/react/chat/components/";
    const relative = file.slice(prefix.length),
      folder = path.dirname(relative);
    const parent = path.join(legacy, "components", folder);
    let legacyCandidates = [];
    try {
      legacyCandidates = (await walk(parent))
        .filter((f) => f.endsWith(".scss"))
        .map((f) => path.relative(repo, f));
    } catch {}
    styleModules.push({
      file: rel,
      owner,
      styleDefinitions,
      sourceSha256: hash(text),
      legacyCandidates,
      classification:
        "Not yet reviewed: inventory only; no mechanical equivalence inferred",
      variables: [
        ...new Set(
          variableRefs.filter((v) => v.file === rel).map((v) => v.variable),
        ),
      ],
    });
  }
}
const unknown = [
  ...new Set(
    variableRefs
      .filter((r) => !byVariable.has(r.variable))
      .map((r) => r.variable),
  ),
].map((variable) => ({
  variable,
  consumers: variableRefs.filter((r) => r.variable === variable),
  status: "Not mapped to public string theme key",
}));
const diffs = execFileSync(
  "git",
  ["diff", "--name-only", "9ee057613", "HEAD", "--", ...sourceRoots],
  { cwd: repo, encoding: "utf8" },
)
  .trim()
  .split("\n")
  .filter(Boolean);
const runtimeDiffs = diffs.filter(
  (f) => /\.(ts|tsx)$/.test(f) && !f.includes("__tests__"),
);
await fs.writeFile(
  out + "/source-provenance.json",
  JSON.stringify(
    {
      repo,
      head: execFileSync("git", ["rev-parse", "HEAD"], {
        cwd: repo,
        encoding: "utf8",
      }).trim(),
      dirty: execFileSync("git", ["status", "--short"], {
        cwd: repo,
        encoding: "utf8",
      }),
      matchingVerifiedSource: "9ee0576133fbb1c444d03c169a81893ebf7631fd",
      runtimeDiffs,
      sourceHashes: Object.fromEntries(
        [...sources].map(([f, s]) => [path.relative(repo, f), hash(s.text)]),
      ),
    },
    null,
    2,
  ) + "\n",
);
for (const [name, data] of Object.entries({
  "token-ledger": Array.from(fields.values()),
  "consumed-variables": variableRefs,
  "unmapped-variables": unknown,
  "selector-inventory": selectors,
  "important-decisions": important,
  "style-source-inventory": styleModules,
  "default-themes": {
    light: core.defaultLightTheme,
    dark: core.defaultDarkTheme,
  },
}))
  await fs.writeFile(
    out + "/" + name + ".json",
    JSON.stringify(data, null, 2) + "\n",
  );
const summary = {
  sourceFiles: sources.size,
  publicFields: fields.size,
  paletteFields: palettes.length,
  publicStringFields: [...fields.values()].filter((f) => f.variable).length,
  usedPublicStringFields: [...fields.values()].filter(
    (f) => f.cssConsumers.length,
  ).length,
  contextFields: [...fields.values()].filter((f) => f.contextConsumers.length)
    .length,
  variableReferences: variableRefs.length,
  unmappedVariables: unknown.map((r) => r.variable),
  styleModules: styleModules.length,
  selectors: selectors.length,
  whereSelectors: selectors.filter((s) => s.where).length,
  important: important.length,
  runtimeDiffs,
};
await fs.writeFile(
  out + "/inventory-summary.json",
  JSON.stringify(summary, null, 2) + "\n",
);
console.log(JSON.stringify(summary, null, 2));
async function walk(dir) {
  let files = [];
  for (const d of await fs.readdir(dir, { withFileTypes: true })) {
    const f = path.join(dir, d.name);
    if (d.isDirectory()) files.push(...(await walk(f)));
    else if (d.isFile()) files.push(f);
  }
  return files;
}
