import fs from "node:fs/promises";
import { execFileSync } from "node:child_process";
import { createHash } from "node:crypto";
const root = "/Users/ankitdas/.codex/worktrees/component-comparison/openui",
  relative = "examples/miscellaneous/component-comparison/bench/cases.json",
  out = "/private/tmp/openui-theme-cascade-verification";
const commit = execFileSync(
    "git",
    ["log", "-1", "--format=%H", "--", relative],
    { cwd: root, encoding: "utf8" },
  ).trim(),
  bytes = execFileSync("git", ["show", commit + ":" + relative], { cwd: root }),
  cases = JSON.parse(bytes);
const inputs = cases.map((c) => ({
  id: c.id,
  name: c.name,
  source: c.source,
  coverage: c.coverage,
  setup: c.setup,
  knownIssues: c.knownIssues ?? [],
  scope:
    "Borrowed public component input only; lab verdicts/assertions/preset metadata are not reused as independent evidence",
}));
await fs.writeFile(
  out + "/component-inputs.json",
  JSON.stringify(inputs, null, 2) + "\n",
);
await fs.writeFile(
  out + "/component-input-provenance.json",
  JSON.stringify(
    {
      source: root,
      path: relative,
      commit,
      sha256: createHash("sha256").update(bytes).digest("hex"),
      count: cases.length,
      coverage: [...new Set(inputs.flatMap((c) => c.coverage))],
      execution: "Not run",
      knownUnstable: inputs
        .filter(
          (c) =>
            typeof c.setup?.directHorizontal?.height === "string" &&
            c.setup?.directHorizontal?.fitLegendInHeight,
        )
        .map((c) => c.id),
    },
    null,
    2,
  ) + "\n",
);
await fs.copyFile(
  out + "/component-inputs.json",
  out + "/consumer/app/component-inputs.json",
);
console.log(
  JSON.stringify({
    commit,
    cases: cases.length,
    components: new Set(inputs.flatMap((c) => c.coverage)).size,
    executed: 0,
  }),
);
