import fs from "node:fs/promises";
import { createHash } from "node:crypto";
import { execFileSync } from "node:child_process";
import assert from "node:assert/strict";
const source = "/Users/ankitdas/.codex/worktrees/component-comparison/openui",
  relative =
    "examples/miscellaneous/component-comparison/src/theme-presets.json",
  out = "/private/tmp/openui-theme-cascade-verification";
const bytes = execFileSync(
  "git",
  [
    "show",
    (process.argv[2] ?? "5190f9a52dd361ad160f5b1bccc892ea51d23f1d") +
      ":" +
      relative,
  ],
  { cwd: source },
);
const f = JSON.parse(bytes);
const hash = (b) => createHash("sha256").update(b).digest("hex");
let rows = [];
const fields = JSON.parse(
  await fs.readFile(out + "/token-ledger.json", "utf8"),
);
for (const p of f.presets) {
  const actual = hash(
    JSON.stringify({
      version: f.version,
      id: p.id,
      label: p.label,
      lightTheme: p.lightTheme,
      darkTheme: p.darkTheme,
    }),
  );
  assert.equal(actual, p.definitionHash);
  rows.push({
    id: p.id,
    definitionHash: actual,
    lightKeys: Object.keys(p.lightTheme).length,
    darkKeys: Object.keys(p.darkTheme).length,
    missingLight: fields
      .filter((x) => !Object.hasOwn(p.lightTheme, x.field))
      .map((x) => x.field),
    unknown: Object.keys(p.lightTheme).filter(
      (k) => !fields.some((x) => x.field === k),
    ),
  });
}
await fs.writeFile(out + "/theme-presets.json", bytes);
await fs.writeFile(
  out + "/theme-preset-provenance.json",
  JSON.stringify(
    {
      source,
      commit: process.argv[2] ?? "5190f9a52dd361ad160f5b1bccc892ea51d23f1d",
      path: relative,
      sha256: hash(bytes),
      presets: rows,
    },
    null,
    2,
  ) + "\n",
);
console.log(
  JSON.stringify({
    sha256: hash(bytes),
    presets: rows.map((r) => ({
      id: r.id,
      lightKeys: r.lightKeys,
      darkKeys: r.darkKeys,
      missing: r.missingLight.length,
      unknown: r.unknown,
    })),
  }),
);
