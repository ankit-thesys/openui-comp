import fs from "node:fs/promises";
import path from "node:path";
import { createHash } from "node:crypto";
const root = "/Users/ankitdas/.codex/worktrees/production-core-kits/openui",
  out = "/private/tmp/openui-theme-cascade-verification",
  base = out + "/source-candidates/base";
await fs.mkdir(base + "/packages/react-ui-core", { recursive: true });
for (const file of ["tsconfig.json"])
  await fs.copyFile(root + "/" + file, base + "/" + file);
for (const file of [
  "package.json",
  "tsconfig.json",
  "tsdown.config.ts",
  "README.md",
  "THIRD_PARTY_NOTICES.md",
])
  await fs.copyFile(
    root + "/packages/react-ui-core/" + file,
    base + "/packages/react-ui-core/" + file,
  );
await fs.cp(
  root + "/packages/react-ui-core/src",
  base + "/packages/react-ui-core/src",
  { recursive: true },
);
const provenance = JSON.parse(
  await fs.readFile(out + "/source-provenance.json", "utf8"),
);
let count = 0;
for (const [file, expected] of Object.entries(provenance.sourceHashes)) {
  if (!file.startsWith("packages/react-ui-core/")) continue;
  const actual = createHash("sha256")
    .update(await fs.readFile(base + "/" + file))
    .digest("hex");
  if (actual !== expected) throw Error("Source copy differs " + file);
  count++;
}
const manifest = JSON.parse(
  await fs.readFile(out + "/counterfactual-manifest.json", "utf8"),
);
await fs.writeFile(
  out + "/source-candidate-plan.json",
  JSON.stringify(
    {
      base,
      productionHead: provenance.head,
      verifiedSourceFiles: count,
      dependencies:
        "Not installed; build and artifact consumption pending serialized execution window",
      candidateBuilds: manifest.map((x) => ({
        id: x.id,
        base,
        replaceOnly: {
          file: x.file,
          content: out + "/counterfactuals/" + x.id + "/remove-only.ts",
        },
        candidateSourceSha256: x.candidateSha256,
        status: "Prepared, not built or browser tested",
      })),
      approvedRemovals: [],
    },
    null,
    2,
  ) + "\n",
);
console.log(
  JSON.stringify({
    copiedAndHashChecked: count,
    candidatePlans: manifest.length,
    buildsRun: 0,
  }),
);
