import fs from "node:fs/promises";
import path from "node:path";
import { createRequire } from "node:module";
import { createHash } from "node:crypto";
const root = "/Users/ankitdas/.codex/worktrees/production-core-kits/openui",
  out = "/private/tmp/openui-theme-cascade-verification";
const req = createRequire(root + "/packages/react-ui/package.json"),
  ts = req("typescript"),
  sass = req("sass"),
  postcss = req("postcss");
const digest = (s) => createHash("sha256").update(s).digest("hex");
const read = (n) =>
  fs.readFile(out + "/" + n + ".json", "utf8").then(JSON.parse);
const sources = (await read("source-provenance")).sourceHashes;
const modules = [],
  declarations = [],
  spreads = [],
  legacy = [];
await fs.mkdir(out + "/expanded-legacy", { recursive: true });
await fs.mkdir(out + "/counterfactuals", { recursive: true });
for (const file of Object.keys(sources)) {
  const text = await fs.readFile(root + "/" + file, "utf8"),
    ast = ts.createSourceFile(
      file,
      text,
      ts.ScriptTarget.Latest,
      true,
      file.endsWith(".tsx") ? ts.ScriptKind.TSX : ts.ScriptKind.TS,
    );
  if (!/from ["']goober["']/.test(text)) continue;
  const loc = (n) => ({
    file,
    line: ast.getLineAndCharacterOfPosition(n.getStart()).line + 1,
  });
  let objects = 0,
    calls = 0;
  function visit(n) {
    if (
      ts.isCallExpression(n) &&
      ["css", "keyframes"].includes(n.expression.getText(ast))
    )
      calls++;
    if (ts.isPropertyAssignment(n)) {
      if (ts.isObjectLiteralExpression(n.initializer)) objects++;
      else {
        const ancestry = [];
        let p = n;
        while (p) {
          if (ts.isPropertyAssignment(p)) ancestry.unshift(p.name.getText(ast));
          if (ts.isVariableDeclaration(p)) {
            ancestry.unshift(p.name.getText(ast));
            break;
          }
          p = p.parent;
        }
        declarations.push({
          ...loc(n),
          path: ancestry,
          property: n.name.getText(ast),
          expression: n.initializer.getText(ast),
          review: "Not covered: expression inventory only",
        });
      }
    }
    if (ts.isSpreadAssignment(n))
      spreads.push({ ...loc(n), expression: n.expression.getText(ast) });
    ts.forEachChild(n, visit);
  }
  visit(ast);
  const kind = /\.tsx$/.test(file)
    ? "registration/component"
    : /CSSAttribute|css\(|keyframes\(/.test(text)
      ? "definition or shared declaration"
      : "utility";
  modules.push({
    file,
    kind,
    objectBlocks: objects,
    registrationCalls: calls,
    sha256: digest(text),
  });
}
async function walk(dir) {
  let all = [];
  for (const e of await fs.readdir(dir, { withFileTypes: true })) {
    const f = path.join(dir, e.name);
    if (e.isDirectory()) all.push(...(await walk(f)));
    else if (e.name.endsWith(".scss")) all.push(f);
  }
  return all;
}
for (const file of await walk(root + "/packages/react-ui/src/components")) {
  const rel = path.relative(root, file),
    family = rel.split("/")[4];
  if (!modules.some((m) => m.file.includes("/" + family + "/"))) continue;
  try {
    const result = sass.compile(file, {
      style: "expanded",
      sourceMap: true,
      logger: { warn() {}, debug() {} },
    });
    const css = postcss.parse(result.css),
      rules = [];
    css.walkRules((r) =>
      rules.push({
        selector: r.selector,
        declarations: r.nodes
          .filter((n) => n.type === "decl")
          .map((d) => ({
            property: d.prop,
            value: d.value,
            important: d.important === true,
          })),
        ancestors: parents(r),
      }),
    );
    const name = rel.replaceAll("/", "__");
    await fs.writeFile(out + "/expanded-legacy/" + name + ".css", result.css);
    await fs.writeFile(
      out + "/expanded-legacy/" + name + ".map.json",
      JSON.stringify(result.sourceMap),
    );
    legacy.push({
      file: rel,
      sha256: digest(await fs.readFile(file)),
      expandedSha256: digest(result.css),
      rules,
      loadedUrls: result.loadedUrls.map(String),
      status:
        "Expanded with standard Sass; declaration equivalence not yet reviewed",
    });
  } catch (e) {
    legacy.push({ file: rel, status: "Failed expansion", error: e.message });
  }
}
function parents(n) {
  const a = [];
  while (n.parent) {
    n = n.parent;
    if (n.type === "atrule") a.unshift("@" + n.name + " " + n.params);
  }
  return a;
}
const important = await read("important-decisions");
const manifest = [];
for (let i = 0; i < important.length; i++) {
  const item = important[i],
    original = await fs.readFile(root + "/" + item.file, "utf8"),
    lines = original.split("\n");
  if (!lines[item.line - 1].includes("!important"))
    throw Error("Line mismatch " + i);
  const count = lines[item.line - 1].split("!important").length - 1;
  if (count !== 1) throw Error("Ambiguous target " + i);
  lines[item.line - 1] = lines[item.line - 1].replace(" !important", "");
  const candidate = lines.join("\n"),
    id = String(i + 1).padStart(2, "0"),
    dir = out + "/counterfactuals/" + id;
  await fs.mkdir(dir, { recursive: true });
  await fs.writeFile(dir + "/original.ts", original);
  await fs.writeFile(dir + "/remove-only.ts", candidate);
  await fs.writeFile(
    dir + "/case.json",
    JSON.stringify(
      {
        ...item,
        id,
        originalSha256: digest(original),
        candidateSha256: digest(candidate),
        changedLine: item.line,
        assertion:
          "Only one literal !important removed; all other bytes unchanged",
        browserStatus: "Not covered",
      },
      null,
      2,
    ),
  );
  manifest.push({
    ...item,
    id,
    originalSha256: digest(original),
    candidateSha256: digest(candidate),
    browserStatus: "Not covered",
  });
}
for (const [name, data] of Object.entries({
  "style-module-classification": modules,
  "authored-declarations": declarations,
  "spread-dependencies": spreads,
  "expanded-legacy-inventory": legacy,
  "counterfactual-manifest": manifest,
}))
  await fs.writeFile(
    out + "/" + name + ".json",
    JSON.stringify(data, null, 2) + "\n",
  );
console.log(
  JSON.stringify({
    modules: modules.length,
    definitions: modules.filter(
      (x) => x.kind === "definition or shared declaration",
    ).length,
    registrationComponents: modules.filter(
      (x) => x.kind === "registration/component",
    ).length,
    declarations: declarations.length,
    spreads: spreads.length,
    expandedScss: legacy.length,
    scssErrors: legacy
      .filter((x) => x.error)
      .map((x) => ({ file: x.file, error: x.error })),
    counterfactuals: manifest.length,
  }),
);
