import fs from "node:fs/promises";
import { createHash } from "node:crypto";
const out = "/private/tmp/openui-theme-cascade-verification";
const fields = JSON.parse(
    await fs.readFile(out + "/token-ledger.json", "utf8"),
  ),
  base = JSON.parse(await fs.readFile(out + "/theme-presets.json", "utf8"));
const fixtures = [];
for (const p of base.presets.filter((p) => p.id !== "default"))
  for (const mode of ["light", "dark"]) {
    const partial = p[mode + "Theme"],
      full = {};
    let i = 0;
    for (const f of fields) {
      i++;
      if (f.variable && f.defaultLight === null) continue;
      let value;
      if (f.group === "ColorTheme")
        value = `oklch(${mode === "light" ? "0.64" : "0.74"} 0.11 ${(i * 17 + (p.id === "cyberpunk" ? 190 : 25)) % 360} / 1)`;
      else if (f.group === "LayoutTheme") value = `${3 + (i % 19)}px`;
      else if (f.group === "EffectTheme")
        value = `${(i % 4) + 1}px ${(i % 5) + 2}px ${(i % 7) + 4}px 1px oklch(0.31 0.04 43 / 0.37)`;
      else if (f.group === "ChartColorPalette")
        value = Array.from(
          { length: 5 },
          (_, n) => `oklch(0.67 0.14 ${(i * 19 + n * 61) % 360} / 1)`,
        );
      else if (
        f.field.includes("LetterSpacing") ||
        f.field.startsWith("letterSpacing")
      )
        value = `0.${String(21 + (i % 17)).padStart(2, "0")}em`;
      else if (f.field.startsWith("fontVariation"))
        value = `"wght" ${510 + (i % 30)}`;
      else if (f.field.startsWith("fontWeight")) value = String(510 + (i % 30));
      else if (f.field.startsWith("fontSize")) value = `${17 + (i % 9)}px`;
      else if (f.field.startsWith("lineHeight")) value = `1.${31 + (i % 19)}`;
      else if (f.field.startsWith("font"))
        value =
          p.id === "cyberpunk" ? "ui-monospace, monospace" : "Georgia, serif";
      else
        value = `${510 + (i % 30)} ${17 + (i % 9)}px/1.${31 + (i % 19)} ${p.id === "cyberpunk" ? "ui-monospace, monospace" : "Georgia, serif"}`;
      full[f.field] = value;
    }
    Object.assign(full, partial);
    const payload = {
      preset: p.id,
      mode,
      baseDefinitionHash: p.definitionHash,
      partial,
      full,
      omittedUnsupportedFields: fields
        .filter((f) => f.variable && f.defaultLight === null)
        .map((f) => f.field),
      unchangedFromModeDefault: fields
        .filter(
          (f) =>
            Object.hasOwn(full, f.field) &&
            JSON.stringify(full[f.field]) ===
              JSON.stringify(mode === "light" ? f.defaultLight : f.defaultDark),
        )
        .map((f) => f.field),
    };
    fixtures.push({
      ...payload,
      fixtureHash: createHash("sha256")
        .update(JSON.stringify(payload))
        .digest("hex"),
    });
  }
await fs.writeFile(
  out + "/theme-fixtures.json",
  JSON.stringify(
    {
      purpose:
        "Test-only exhaustive supplemental overrides; base shared presets unchanged. Not lab presets or production theme API.",
      baseVersion: base.version,
      fixtures,
    },
    null,
    2,
  ) + "\n",
);
console.log(
  JSON.stringify(
    fixtures.map((f) => ({
      preset: f.preset,
      mode: f.mode,
      fields: Object.keys(f.full).length,
      unchanged: f.unchangedFromModeDefault,
      omitted: f.omittedUnsupportedFields,
      hash: f.fixtureHash,
    })),
  ),
);
