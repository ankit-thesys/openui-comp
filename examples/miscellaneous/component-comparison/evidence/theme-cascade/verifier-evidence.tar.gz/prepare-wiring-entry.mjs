import fs from "node:fs/promises";
const out = "/private/tmp/openui-theme-cascade-verification";
let s = await fs.readFile(out + "/consumer/app/main.jsx", "utf8");
s = s.replace(
  "caseId='direct'})",
  "caseId='direct',isStreaming=false,extra=false,printing=false})",
);
s = s
  .replace(
    "const body=caseSource?<Renderer",
    "const body=extra?<ExtraComponents/>:caseSource?<Renderer",
  )
  .replace(
    "response={caseSource} library={openuiChatLibrary}",
    "response={caseSource} isStreaming={isStreaming} library={openuiChatLibrary}",
  );
const extra = `
const data=[{category:'A',one:4,two:7},{category:'B',one:8,two:5},{category:'C',one:6,two:9}];
function ExtraComponents(){return <>
<section data-extra="buttons">{['primary','secondary','tertiary'].flatMap(variant=>['normal','destructive'].flatMap(buttonType=>[false,true].map(disabled=><UI.Button key={variant+buttonType+disabled} variant={variant} buttonType={buttonType} disabled={disabled}>{variant+' '+buttonType}</UI.Button>)))}</section>
<section data-extra="typography">{['title-text','number-title-text','text-subtext','highlight-text-number-subtext','text','highlight-text','number','highlight-number'].flatMap(variant=>['xs','sm','md','lg'].flatMap(size=>['text','number','textOnly'].map(type=><UI.TextBlockView key={variant+size+type} variant={variant} size={size} type={type} primary="234" secondary="Secondary" tertiary="Tertiary" secondaryTone={size==='sm'?'negative':'positive'}/>)))}</section>
<section data-extra="icons">{['neutral','info','success','warning','danger','inverted'].map(variant=><UI.IconTag key={variant} icon={{name:'Star',category:'lucide'}} variant={variant}/>)}</section>
<section data-extra="skeletons"><UI.Skeleton count={2}/><UI.TableSkeleton rows={2} columns={3}/><UI.PieChartSkeleton/><UI.DotMatrixLoader/></section>
<section data-extra="charts" style={{width:650}}>{['BarChart','LineChart','AreaChart','RadarChart','HorizontalBarChart','PieChart','RadialChart','HeatmapChart','FunnelChart','SegmentedBar'].map(name=>{const C=UI[name];return <div key={name} data-chart={name} style={{width:640,height:300}}><C data={data} categoryKey="category" dataKey="one" dataKeys={['one','two']} height={240} width={640} fitLegendInHeight={false} isAnimationActive={false}/></div>})}<div data-chart="CalendarHeatmap"><UI.CalendarHeatmap data={[{date:'2026-03-01',value:1},{date:'2026-03-02',value:4}]} range={['2026-03-01','2026-03-15']} columnSeparators={{groupBy:{every:1},showLabels:true}}/></div>{['MiniAreaChart','MiniBarChart','MiniLineChart'].map(name=>{const C=UI[name];return <div key={name} data-chart={name}><C data={[3,6,4]} size={120} isAnimationActive={false}/></div>})}</section></>}
`;
s = s.replace("function App(", extra + "\nfunction App(");
await fs.writeFile(out + "/consumer/app/wiring.jsx", s);
await fs.writeFile(
  out + "/consumer/wiring.html",
  (await fs.readFile(out + "/consumer/index.html", "utf8")).replace(
    "/app/main.jsx",
    "/app/wiring.jsx",
  ),
);
