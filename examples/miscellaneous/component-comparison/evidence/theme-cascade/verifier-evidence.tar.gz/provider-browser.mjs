import fs from "node:fs/promises";
import assert from "node:assert/strict";
import {
  chromium,
  executablePath,
  out,
  hosts,
  schemes,
  fullSchemes,
  openPage,
  render,
  settle,
  save,
} from "./browser-common.mjs";
const defaults = JSON.parse(
    await fs.readFile(out + "/default-themes.json", "utf8"),
  ),
  presets = JSON.parse(
    await fs.readFile(out + "/theme-presets.json", "utf8"),
  ).presets,
  supp = JSON.parse(
    await fs.readFile(out + "/theme-fixtures.json", "utf8"),
  ).fixtures;
const browser = await chromium.launch({ executablePath, headless: true });
let results = [],
  assertions = 0;
try {
  for (const id of ["baseline", "legacy"])
    for (const host of hosts) {
      const page = await openPage(browser, id, host.host, host.order);
      for (const scheme of [...schemes, ...fullSchemes]) {
        const t = scheme.full
          ? supp.find(
              (f) => f.preset === scheme.preset && f.mode === scheme.mode,
            ).full
          : {
              ...defaults[scheme.mode],
              ...presets.find((p) => p.id === scheme.preset)[
                scheme.mode + "Theme"
              ],
            };
        let checks = [],
          portals = [];
        try {
          await render(page, { ...scheme, siblings: true, nested: true });
          checks = await page.evaluate(
            ({ t, mode }) => {
              const records = [];
              function check(label, pass, actual, expected) {
                records.push({ label, pass, actual, expected });
              }
              function normalized(property, value) {
                const e = document.createElement("span");
                e.style.setProperty(property, value);
                document.body.append(e);
                const v = getComputedStyle(e).getPropertyValue(property);
                e.remove();
                return v;
              }
              const input = document.querySelector(
                  '#theme-scope input[aria-label="Ordinary input"]',
                ),
                s = getComputedStyle(input);
              for (const [field, property] of [
                ["textNeutralPrimary", "color"],
                ["highlightSubtle", "background-color"],
                ["radiusM", "border-radius"],
                ["fontVariationRegular", "font-variation-settings"],
              ]) {
                const variable =
                  "--openui-" +
                  field.replace(/([a-z])([A-Z])/g, "$1-$2").toLowerCase();
                check(
                  field + " variable",
                  s.getPropertyValue(variable).trim() === t[field],
                  s.getPropertyValue(variable).trim(),
                  t[field],
                );
                check(
                  field + " computed",
                  s.getPropertyValue(property) ===
                    normalized(property, t[field]),
                  s.getPropertyValue(property),
                  normalized(property, t[field]),
                );
              }
              check(
                "context mode",
                document.querySelector('[data-context="primary"]').dataset
                  .mode === mode,
                document.querySelector('[data-context="primary"]').dataset.mode,
                mode,
              );
              const nested = getComputedStyle(
                document.querySelector('[aria-label="Nested input"]'),
              );
              check(
                "nested override",
                nested
                  .getPropertyValue("--openui-text-neutral-primary")
                  .trim() === "oklch(0.42 0.12 27 / 1)",
                nested.getPropertyValue("--openui-text-neutral-primary").trim(),
                "oklch(0.42 0.12 27 / 1)",
              );
              const other = getComputedStyle(
                document.querySelector('[aria-label="Sibling input"]'),
              );
              check(
                "sibling isolation",
                other
                  .getPropertyValue("--openui-text-neutral-primary")
                  .trim() !==
                  s.getPropertyValue("--openui-text-neutral-primary").trim() ||
                  window.fixtureConfig.preset === "default",
                other.getPropertyValue("--openui-text-neutral-primary").trim(),
                "Other preset",
              );
              return records;
            },
            { t, mode: scheme.mode },
          );
          for (const [kind, trigger, selector] of [
            [
              "Select",
              '#theme-scope [aria-label="Fixture select"]',
              '.openui-select-content[data-state="open"]',
            ],
            [
              "Calendar",
              "#theme-scope .openui-calendar-select-trigger",
              ".openui-calendar-select-content-months",
            ],
            [
              "ModelSwitcher",
              '#theme-scope [aria-label="Select model"]',
              ".openui-model-switcher-content",
            ],
          ]) {
            await page.locator(trigger).first().click();
            await settle(page, 180);
            const visible = page
              .locator(selector)
              .filter({ visible: true })
              .first();
            await visible.waitFor({ state: "visible" });
            const proof = await visible.evaluate((node, t) => {
              const s = getComputedStyle(node);
              return {
                className: node.className,
                variable: s
                  .getPropertyValue("--openui-text-neutral-primary")
                  .trim(),
                expected: t.textNeutralPrimary,
                background: s.backgroundColor,
                providerIdentity: [...node.classList].filter((c) =>
                  c.startsWith("openui-theme-portal-"),
                ),
                insideScope: !!node.closest("#theme-scope"),
              };
            }, t);
            portals.push({
              kind,
              ...proof,
              pass:
                proof.variable === proof.expected &&
                (proof.providerIdentity.length > 0 || proof.insideScope),
            });
            await page.keyboard.press("Escape");
            await settle(page, 40);
          }
          await page
            .locator('#theme-scope [aria-label="Fixture tooltip"]')
            .hover();
          await settle(page, 200);
          const tip = page
            .locator(".openui-tooltip-content")
            .filter({ visible: true })
            .first();
          await tip.waitFor({ state: "visible" });
          const proof = await tip.evaluate(
            (node, t) => ({
              variable: getComputedStyle(node)
                .getPropertyValue("--openui-text-neutral-primary")
                .trim(),
              expected: t.textNeutralPrimary,
              providerIdentity: [...node.classList].filter((c) =>
                c.startsWith("openui-theme-portal-"),
              ),
            }),
            t,
          );
          portals.push({
            kind: "Tooltip",
            ...proof,
            pass:
              proof.variable === proof.expected &&
              proof.providerIdentity.length > 0,
          });
          await page.keyboard.press("Escape");
          await page.mouse.move(-10, -10);
          const negative = await page.evaluate(
            ({ variable, expected }) => {
              const node = document.querySelector(
                '#theme-scope input[aria-label="Ordinary input"]',
              );
              const mappings = [];
              for (const sheet of document.styleSheets)
                for (const r of sheet.cssRules ?? [])
                  if (
                    r.style &&
                    r.selectorText
                      ?.split(",")
                      .map((s) => s.trim())
                      .includes("#theme-scope") &&
                    r.style.getPropertyValue(variable)
                  )
                    mappings.push(r);
              if (!mappings.length)
                throw Error("Missing provider mapping before control");
              const before = getComputedStyle(node).color;
              const saved = mappings.map((r) => ({
                r,
                value: r.style.getPropertyValue(variable),
                priority: r.style.getPropertyPriority(variable),
              }));
              for (const s of saved) s.r.style.removeProperty(variable);
              let detected = false;
              try {
                if (!mappings.some((r) => r.style.getPropertyValue(variable)))
                  throw Error("Required provider mapping missing");
                if (
                  getComputedStyle(node).getPropertyValue(variable).trim() !==
                  expected
                )
                  throw Error("Wrong resolved variable");
              } catch {
                detected = true;
              }
              const after = getComputedStyle(node).color;
              for (const s of saved)
                s.r.style.setProperty(variable, s.value, s.priority);
              return {
                detected,
                before,
                after,
                restored: getComputedStyle(node).color === before,
                stillLooksDefault: before === after,
                method:
                  "Removed and restored only the expected provider custom-property mapping; provenance assertion must fail even if a fallback looks unchanged",
              };
            },
            {
              variable: "--openui-text-neutral-primary",
              expected: t.textNeutralPrimary,
            },
          );
          checks.push({
            label: "negative missing-provider mapping",
            pass: negative.detected && negative.restored,
            ...negative,
          });
          await page.evaluate(
            () =>
              (window.__inputBefore = document.querySelector(
                '#theme-scope input[aria-label="Ordinary input"]',
              )),
          );
          await render(page, {
            ...scheme,
            mode: scheme.mode === "light" ? "dark" : "light",
            siblings: true,
            nested: true,
          });
          checks.push({
            label: "mode update preserves input DOM node",
            pass: await page.evaluate(
              () =>
                window.__inputBefore ===
                document.querySelector(
                  '#theme-scope input[aria-label="Ordinary input"]',
                ),
            ),
          });
          await page.evaluate(() => window.fixture.unmount());
          await settle(page);
          const cleanup = await page.evaluate(
            () =>
              [...document.styleSheets]
                .flatMap((s) => [...s.cssRules])
                .filter((r) => r.selectorText?.includes("#theme-scope")).length,
          );
          checks.push({
            label: "provider cleanup",
            pass: cleanup === 0,
            actual: cleanup,
            expected: 0,
          });
          assertions += checks.length + portals.length;
          results.push({
            id,
            ...host,
            ...scheme,
            checks,
            portals,
            status:
              checks.every((c) => c.pass) && portals.every((c) => c.pass)
                ? "Passed"
                : "Failed",
            cssReadiness: page.cssReadiness,
            pageErrors: [...page.verificationErrors],
          });
        } catch (e) {
          results.push({
            id,
            ...host,
            ...scheme,
            status: "Failed harness or product check",
            error: String(e),
            checks,
            portals,
            pageErrors: [...page.verificationErrors],
          });
        }
        await save("provider-browser-progress", {
          browser: browser.version(),
          assertions,
          results,
        });
      }
      await page.close();
      console.log(
        id +
          " " +
          host.host +
          " " +
          host.order +
          " provider cases complete " +
          results.length,
      );
    }
  await save("provider-browser-results", {
    browser: browser.version(),
    assertions,
    results,
    failures: results.filter((r) => r.status !== "Passed"),
  });
  console.log(
    JSON.stringify({
      cases: results.length,
      assertions,
      failed: results.filter((r) => r.status !== "Passed").length,
    }),
  );
} finally {
  await browser.close();
}
