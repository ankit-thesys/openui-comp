import fs from "node:fs/promises";
import { execFileSync } from "node:child_process";
import { createHash } from "node:crypto";
const out = "/private/tmp/openui-theme-cascade-verification";
const records = [],
  hash = (b) => createHash("sha256").update(b).digest("hex");
for (const id of [
  "baseline",
  ...Array.from(
    { length: 16 },
    (_, i) => "remove-" + String(i + 1).padStart(2, "0"),
  ),
]) {
  const tar =
    out + "/artifacts/" + id + "/openuidev-react-ui-core-0.0.0-beta.0.tgz";
  execFileSync(
    "npm",
    [
      "install",
      "--offline",
      "--cache",
      "/private/tmp/chat16-npm-cache",
      "--ignore-scripts",
      "--no-audit",
      "--no-fund",
      tar,
    ],
    { cwd: out + "/consumer", stdio: "ignore" },
  );
  const log = await fs.open(out + "/v2-" + id + "-browser-build.log", "w");
  try {
    execFileSync("node", [out + "/build-fixture.mjs", "v2-" + id], {
      cwd: out + "/consumer",
      stdio: ["ignore", log.fd, log.fd],
    });
  } finally {
    await log.close();
  }
  records.push({
    id: "v2-" + id,
    coreArchiveSha256: hash(await fs.readFile(tar)),
    fixtureSourceSha256: hash(
      await fs.readFile(out + "/consumer/app/main.jsx"),
    ),
    browserEntrySha256: hash(
      await fs.readFile(out + "/browser-dist/v2-" + id + "/index.html"),
    ),
  });
  await fs.writeFile(
    out + "/browser-v2-artifacts.json",
    JSON.stringify(records, null, 2) + "\n",
  );
  console.log("Built v2-" + id);
}
execFileSync("node", [out + "/build-fixture.mjs", "v2-legacy", "legacy"], {
  cwd: out + "/consumer",
  stdio: "ignore",
});
await fs.copyFile(
  out + "/browser-dist/v2-legacy/legacy.html",
  out + "/browser-dist/v2-legacy/index.html",
);
