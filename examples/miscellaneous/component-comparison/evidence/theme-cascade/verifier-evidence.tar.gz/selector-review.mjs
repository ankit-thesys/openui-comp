import fs from "node:fs/promises";
import { createRequire } from "node:module";
const out = "/private/tmp/openui-theme-cascade-verification",
  req = createRequire(import.meta.url),
  parser = req(
    "/Users/ankitdas/.codex/worktrees/production-core-kits/openui/node_modules/.pnpm/postcss-selector-parser@6.1.4/node_modules/postcss-selector-parser",
  );
const max = (a) =>
  a.sort((x, y) => y[0] - x[0] || y[1] - x[1] || y[2] - x[2])[0] ?? [0, 0, 0];
function tuple(n) {
  let t = [0, 0, 0];
  for (const c of n.nodes ?? []) {
    let v = [0, 0, 0];
    if (c.type === "id") v = [1, 0, 0];
    if (["class", "attribute"].includes(c.type)) v = [0, 1, 0];
    if (c.type === "tag") v = [0, 0, 1];
    if (c.type === "pseudo")
      v =
        c.value === ":where"
          ? [0, 0, 0]
          : [":is", ":has", ":not"].includes(c.value)
            ? max(c.nodes.map(tuple))
            : c.value.startsWith("::")
              ? [0, 0, 1]
              : [0, 1, 0];
    t = t.map((x, i) => x + v[i]);
  }
  return t;
}
const spec = (s) => tuple(parser().astSync(s).nodes[0]);
const rows = [];
function add(component, oldSelector, newSelector, rationale, source) {
  rows.push({
    component,
    oldSelector,
    newSelector,
    oldSpecificity: spec(oldSelector),
    newSpecificity: spec(newSelector),
    rationale,
    source,
    runtimeDOMAndWinner: "Not covered",
    overrideCompatibility: "Not covered",
  });
}
add(
  "Input error",
  ".openui-input-error",
  ".GENERATED:where(.openui-input-error)",
  "Preserves the suffix-class specificity instead of adding another class.",
  ["Input/input.scss:60", "Input/input.styles.ts:52"],
);
add(
  "Input focused error",
  ".openui-input-error:focus",
  ".GENERATED:focus:where(.openui-input-error)",
  "Preserves focused-error specificity.",
  ["Input/input.scss:64", "Input/input.styles.ts:56"],
);
add(
  "Input medium",
  ".openui-input-medium",
  ".GENERATED.openui-input-medium",
  "Adds one class; ordinary consumer override implications require testing.",
  ["Input/input.scss:24", "Input/input.styles.ts:20"],
);
add(
  "Label disabled",
  ".openui-label-disabled",
  ".GENERATED.openui-label-disabled",
  "Adds one class; public className/style exist.",
  ["Label/label.scss:8", "Label/label.styles.ts:8"],
);
add(
  "Label required asterisk",
  ".openui-label-required-asterisk",
  ".GENERATED .openui-label-required-asterisk",
  "Scopes a previously global child rule to the Label ancestor; adds one class.",
  ["Label/label.scss:14", "Label/label.styles.ts:12"],
);
add(
  "Calendar Select base",
  ".openui-calendar-container .openui-calendar-select-trigger",
  ".GENERATED :where(.openui-calendar-select-trigger)",
  "Intentional deboost: source comment says Select state rules must outrank this base independent of registration order. Base-vs-base tie/order still needs actual emitted-order evidence.",
  [
    "Calendar/components/calendarHelperComponents.scss:3",
    "Calendar/calendar.styles.ts:148",
  ],
);
add(
  "Calendar mobile viewport",
  ".openui-calendar-container .openui-calendar-select-content-years .openui-calendar-select-viewport-mobile",
  ".GENERATED .openui-calendar-select-content-years .openui-calendar-select-viewport:where(.openui-calendar-select-viewport-mobile)",
  "Preserves specificity when requiring the shared viewport class as well as mobile modifier; requires both classes.",
  [
    "Calendar/components/calendarHelperComponents.scss:47",
    "Calendar/calendar.styles.ts:174",
  ],
);
add(
  "Slider value input",
  ".openui-slider-block__input",
  ".GENERATED .openui-slider-block__input",
  "Adds one ancestor class. Important removal competes with Input size selectors of equal specificity in the new package.",
  ["Slider/slider.scss:243", "Slider/sliderBlock.styles.ts:46"],
);
add(
  "Slider error input",
  ".openui-slider-block__validated-input .openui-slider-block__input-error",
  ".GENERATED .openui-slider-block__validated-input .openui-slider-block__input-error",
  "Adds one ancestor class; removal must preserve danger border during focus and disabled combinations.",
  ["Slider/slider.scss:238", "Slider/sliderBlock.styles.ts:42"],
);
add(
  "Sources hovered item",
  ".openui-listed-sources-item-container--has-url:hover",
  ".GENERATED.openui-listed-sources-item-container--has-url:hover",
  "Adds one class and requires generated container class. Important retention/removal and caller overrides need actual match evidence.",
  ["Sources/sources.scss:9", "Sources/listedSources.styles.ts:31"],
);
add(
  "CodeBlock highlighter",
  ".openui-code-block-wrapper .openui-code-block-syntax-highlighter",
  ".GENERATED .openui-code-block-syntax-highlighter",
  "Equivalent selector specificity; important currently beats default inline margin.",
  ["CodeBlock/codeBlock.scss:29", "CodeBlock/codeBlock.styles.ts:16"],
);
for (const pseudo of ["", ":first-child", ":last-child"])
  add(
    "Markdown highlighter" + pseudo,
    ".openui-markdown-renderer .openui-code-block-syntax-highlighter" + pseudo,
    ".GENERATED .openui-code-block-syntax-highlighter" + pseudo,
    "Equivalent selector specificity; first/last refer to highlighter siblings inside CodeBlock, not position of the code-block wrapper in markdown.",
    [
      "MarkDownRenderer/markDownRenderer.scss",
      "MarkDownRenderer/markdown.styles.ts:81",
    ],
  );
await fs.writeFile(
  out + "/reviewed-selector-entries.json",
  JSON.stringify(rows, null, 2) + "\n",
);
console.log(
  JSON.stringify({ reviewedStaticEntries: rows.length, runtimePasses: 0 }),
);
