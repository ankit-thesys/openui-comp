import fs from "node:fs/promises";
import { createRequire } from "node:module";
const req = createRequire(
    "/Users/ankitdas/.codex/worktrees/2d0f/openui/packages/react-ui-core/package.json",
  ),
  { chromium } = req("playwright");
const out = "/private/tmp/openui-theme-cascade-verification",
  browser = await chromium.launch({
    executablePath:
      "/private/tmp/beta17-cft/156.0.8078.47/chrome-mac-arm64/Google Chrome for Testing.app/Contents/MacOS/Google Chrome for Testing",
    headless: true,
  });
let rows = [];
try {
  for (const id of ["baseline", "legacy"]) {
    const page = await browser.newPage({
        viewport: { width: 1280, height: 1000 },
      }),
      errors = [],
      external = [];
    page.on("pageerror", (e) => errors.push(String(e)));
    await page.route("**/*", (route) => {
      const url = route.request().url();
      if (
        !url.startsWith("http://127.0.0.1:4317/") &&
        !url.startsWith("data:")
      ) {
        external.push(url);
        return route.abort();
      }
      return route.continue();
    });
    await page.goto(
      "http://127.0.0.1:4317/" + id + "/?host=plain&order=before",
    );
    await page.waitForFunction(() => !!window.fixture);
    await page.waitForTimeout(500);
    rows.push({
      id,
      errors,
      external,
      fixture: await page.evaluate(() => ({
        errors: window.fixtureObservations.errors,
        body: document.body.innerText.slice(0, 400),
        inputs: document.querySelectorAll("input").length,
        styles: [...document.styleSheets].map((s) => s.href ?? s.ownerNode?.id),
        presetHashes: window.fixture.presetHashes,
        cssProbes: window.themeProbes.inspectConsumers().observations.length,
      })),
    });
    await page.screenshot({
      path: out + "/smoke-" + id + ".png",
      fullPage: true,
    });
    await page.close();
  }
  await fs.writeFile(
    out + "/smoke-browser-results.json",
    JSON.stringify({ browser: browser.version(), rows }, null, 2) + "\n",
  );
  console.log(JSON.stringify(rows));
} finally {
  await browser.close();
}
