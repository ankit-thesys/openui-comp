import fs from "node:fs/promises";
import { createRequire } from "node:module";
import assert from "node:assert/strict";
const out = "/private/tmp/openui-theme-cascade-verification",
  req = createRequire(import.meta.url),
  parser = req(
    "/Users/ankitdas/.codex/worktrees/production-core-kits/openui/node_modules/.pnpm/postcss-selector-parser@6.1.4/node_modules/postcss-selector-parser",
  );
const add = (a, b) => a.map((v, i) => v + b[i]);
const max = (a) =>
  a.sort((x, y) => y[0] - x[0] || y[1] - x[1] || y[2] - x[2])[0] ?? [0, 0, 0];
function tuple(node) {
  let t = [0, 0, 0];
  for (const n of node.nodes ?? []) {
    let v = [0, 0, 0];
    if (n.type === "id") v = [1, 0, 0];
    if (["class", "attribute"].includes(n.type)) v = [0, 1, 0];
    if (n.type === "tag") v = [0, 0, 1];
    if (n.type === "nesting") v = [0, 1, 0];
    if (n.type === "pseudo") {
      if (n.value === ":where") v = [0, 0, 0];
      else if ([":is", ":not", ":has"].includes(n.value))
        v = max(n.nodes.map(tuple));
      else if (
        n.value.startsWith("::") ||
        [":before", ":after", ":first-line", ":first-letter"].includes(n.value)
      )
        v = [0, 0, 1];
      else v = [0, 1, 0];
    }
    t = add(t, v);
  }
  return t;
}
function specificity(s) {
  const ast = parser().astSync(s);
  return ast.nodes.map((n) => ({
    selector: n.toString(),
    specificity: tuple(n),
  }));
}
for (const [s, expected] of [
  [".a:where(.b:hover)", [0, 1, 0]],
  [".a:focus:not(.b)", [0, 3, 0]],
  ["#a:is(.b,div)", [1, 1, 0]],
  [".a:has(+ p)", [0, 1, 1]],
  [".a::before", [0, 1, 1]],
  ["& .a", [0, 2, 0]],
])
  assert.deepEqual(specificity(s)[0].specificity, expected);
const object = JSON.parse(
    await fs.readFile(out + "/selector-inventory.json", "utf8"),
  ),
  templates = JSON.parse(
    await fs.readFile(out + "/template-selectors.json", "utf8"),
  );
let rows = [];
for (const row of [...object, ...templates]) {
  if (
    row.selector.startsWith("@") ||
    /^\d+%/.test(row.selector) ||
    row.tag === "keyframes"
  )
    continue;
  try {
    rows.push({
      ...row,
      relativeSpecificity: specificity(row.selector),
      limitation:
        "Relative & is counted as one generated class. Enclosing nested selectors, runtime DOM matches, and competing rules still require resolution.",
      runtimeStatus: "Not covered",
    });
  } catch (e) {
    rows.push({ ...row, error: e.message, runtimeStatus: "Not covered" });
  }
}
await fs.writeFile(
  out + "/selector-specificity.json",
  JSON.stringify(rows, null, 2) + "\n",
);
console.log(
  JSON.stringify({
    checks: 6,
    selectors: rows.length,
    where: rows.filter((r) => r.where).length,
    parseErrors: rows.filter((r) => r.error).length,
  }),
);
