import fs from "node:fs/promises";
import { createHash } from "node:crypto";
import assert from "node:assert/strict";
import { execFileSync } from "node:child_process";
const out = "/private/tmp/openui-theme-cascade-verification",
  repo = "/Users/ankitdas/.codex/worktrees/production-core-kits/openui";
const json = (n) =>
  fs.readFile(out + "/" + n + ".json", "utf8").then(JSON.parse);
const hash = (b) => createHash("sha256").update(b).digest("hex");
let results = [];
const head = execFileSync("git", ["rev-parse", "HEAD"], {
    cwd: repo,
    encoding: "utf8",
  }).trim(),
  dirty = execFileSync("git", ["status", "--short"], {
    cwd: repo,
    encoding: "utf8",
  });
assert.equal(head, "57ea72e2892df7fdd551c668d4480a0267f90a09");
assert.equal(dirty, "");
results.push({
  check: "Production head and clean status",
  status: "Passed",
  head,
});
const fields = await json("token-ledger"),
  defs = await json("default-themes");
assert.equal(fields.length, new Set(fields.map((x) => x.field)).size);
results.push({
  check: "Public field uniqueness",
  status: "Passed",
  count: fields.length,
});
const missing = fields
  .filter(
    (f) =>
      f.variable &&
      (!Object.hasOwn(defs.light, f.field) ||
        !Object.hasOwn(defs.dark, f.field)),
  )
  .map((f) => f.field);
results.push({
  check: "Public string fields present in defaults",
  status: missing.length ? "Needs review" : "Passed",
  missing,
});
const important = await json("counterfactual-manifest");
assert.equal(important.length, 16);
for (const x of important) {
  const dir = out + "/counterfactuals/" + x.id,
    a = await fs.readFile(dir + "/original.ts", "utf8"),
    b = await fs.readFile(dir + "/remove-only.ts", "utf8");
  assert.equal(hash(a), x.originalSha256);
  assert.equal(hash(b), x.candidateSha256);
  const lines = a.split("\n");
  lines[x.line - 1] = lines[x.line - 1].replace(" !important", "");
  assert.equal(lines.join("\n"), b);
  assert.equal(a, await fs.readFile(repo + "/" + x.file, "utf8"));
  results.push({
    check: "Removal-only integrity " + x.id,
    status: "Passed",
    file: x.file,
    line: x.line,
  });
}
const shared = [];
for (const name of [
  "types.ts",
  "defaultTheme.ts",
  "swatches.ts",
  "utils.ts",
  "useSystemThemeMode.ts",
]) {
  const oldFile =
      repo + "/packages/react-ui/src/components/ThemeProvider/" + name,
    newFile =
      repo + "/packages/react-ui-core/src/components/ThemeProvider/" + name;
  try {
    const old = await fs.readFile(oldFile),
      next = await fs.readFile(newFile);
    shared.push({
      file: name,
      legacySha256: hash(old),
      productionSha256: hash(next),
      equal: old.equals(next),
    });
  } catch (e) {
    shared.push({ file: name, error: e.message });
  }
}
results.push({
  check: "Theme source correspondence",
  status: shared.every((x) => x.equal) ? "Passed" : "Needs review",
  files: shared,
});
const scss = await json("expanded-legacy-inventory");
assert.equal(scss.filter((x) => x.error).length, 0);
results.push({
  check: "Legacy SCSS expansion",
  status: "Passed",
  count: scss.length,
});
await fs.writeFile(
  out + "/static-check-results.json",
  JSON.stringify({ time: new Date().toISOString(), results }, null, 2) + "\n",
);
console.log(
  JSON.stringify({
    checks: results.length,
    needsReview: results.filter((r) => r.status !== "Passed"),
    browserChecks: 0,
  }),
);
