import fs from "node:fs/promises";
import { createRequire } from "node:module";
const repo = "/Users/ankitdas/.codex/worktrees/production-core-kits/openui",
  out = "/private/tmp/openui-theme-cascade-verification",
  req = createRequire(repo + "/packages/react-ui/package.json"),
  ts = req("typescript"),
  postcss = req("postcss");
const hashes = JSON.parse(
  await fs.readFile(out + "/source-provenance.json", "utf8"),
).sourceHashes;
let templates = [],
  decls = [],
  selectors = [],
  errors = [];
for (const file of Object.keys(hashes)) {
  const text = await fs.readFile(repo + "/" + file, "utf8");
  if (!/from ["']goober["']/.test(text)) continue;
  const ast = ts.createSourceFile(
    file,
    text,
    ts.ScriptTarget.Latest,
    true,
    file.endsWith("tsx") ? ts.ScriptKind.TSX : ts.ScriptKind.TS,
  );
  function visit(n) {
    if (
      ts.isTaggedTemplateExpression(n) &&
      ["css", "keyframes"].includes(n.tag.getText(ast))
    ) {
      const raw = n.template.getText(ast).slice(1, -1);
      const line =
        ast.getLineAndCharacterOfPosition(n.template.getStart()).line + 1;
      let i = 0,
        expressions = [];
      const css = raw.replace(/\$\{([^}]+)\}/g, (_, e) => {
        expressions.push(e);
        return "__EXPR_" + i++ + "__";
      });
      const name =
        n.parent.name?.getText(ast) ?? n.parent.getText(ast).slice(0, 80);
      templates.push({
        file,
        line,
        name,
        tag: n.tag.getText(ast),
        expressions,
        raw,
      });
      try {
        const p = postcss.parse(css);
        p.walkDecls((d) => {
          let parents = [];
          for (let r = d.parent; r; r = r.parent) {
            if (r.type === "rule") parents.unshift(r.selector);
            if (r.type === "atrule")
              parents.unshift("@" + r.name + " " + r.params);
          }
          decls.push({
            file,
            line: line + d.source.start.line - 1,
            name,
            selectors: parents,
            property: d.prop,
            value: d.value,
            variables: [...d.value.matchAll(/var\(\s*(--[\w-]+)/g)].map(
              (m) => m[1],
            ),
            unresolvedInterpolation: d.value.includes("__EXPR_"),
          });
        });
        p.walkRules((r) =>
          selectors.push({
            file,
            line: line + r.source.start.line - 1,
            name,
            selector: r.selector,
            where: r.selector.includes(":where("),
            tag: n.tag.getText(ast),
          }),
        );
      } catch (e) {
        errors.push({ file, line, error: e.message });
      }
    }
    ts.forEachChild(n, visit);
  }
  visit(ast);
}
for (const [name, data] of Object.entries({
  "tagged-templates": templates,
  "template-declarations": decls,
  "template-selectors": selectors,
  "template-parse-errors": errors,
}))
  await fs.writeFile(
    out + "/" + name + ".json",
    JSON.stringify(data, null, 2) + "\n",
  );
let modules = JSON.parse(
  await fs.readFile(out + "/style-module-classification.json", "utf8"),
);
for (const m of modules)
  if (templates.some((t) => t.file === m.file))
    m.kind = "definition or shared declaration";
await fs.writeFile(
  out + "/style-module-classification.json",
  JSON.stringify(modules, null, 2) + "\n",
);
console.log(
  JSON.stringify({
    templates: templates.length,
    templateDeclarations: decls.length,
    templateSelectors: selectors.length,
    templateWhere: selectors.filter((x) => x.where).length,
    parseErrors: errors.length,
    definitionModules: modules.filter(
      (m) => m.kind === "definition or shared declaration",
    ).length,
  }),
);
