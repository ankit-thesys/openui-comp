import fs from "node:fs/promises";
import {createRequire} from 'node:module';
const requireTools=createRequire('/Users/ankitdas/.codex/worktrees/production-core-kits/openui/packages/react-ui/package.json');
const postcss=requireTools('postcss');
let fontRuleCache=null;
async function authoredFonts(page){
 if(fontRuleCache)return fontRuleCache;
 const sheets=await page.evaluate(()=>[...document.querySelectorAll('style#_goober')].map(s=>s.textContent));
 const rows=[];
 for(const css of sheets){const tree=postcss.parse(css);tree.walkDecls('font',decl=>{if(!decl.value.includes('var(--openui-'))return;const conditions=[];let parent=decl.parent;while(parent){if(parent.type==='atrule')conditions.push({name:parent.name,params:parent.params});parent=parent.parent}if(conditions.some(c=>!['media','supports'].includes(c.name)))return;rows.push({selector:decl.parent.selector,value:decl.value,conditions})})}
 fontRuleCache=rows;await save('authored-font-rules',rows);return rows;
}
import {
  chromium,
  executablePath,
  out,
  openPage,
  render,
  settle,
  save,
} from "./browser-common.mjs";
const ledger = JSON.parse(
    await fs.readFile(out + "/token-ledger.json", "utf8"),
  ),
  fields = ledger.filter((f) => f.cssConsumers.length && f.variable),
  wanted = fields.map((f) => f.variable),
  fieldMap = Object.fromEntries(fields.map((f) => [f.variable, f.field])),
  fixtures = JSON.parse(
    await fs.readFile(out + "/theme-fixtures.json", "utf8"),
  ).fixtures,
  inputs = JSON.parse(
    await fs.readFile(out + "/component-inputs.json", "utf8"),
  );
const browser = await chromium.launch({ executablePath, headless: true });
const results = [],
  cases = [];
let total = 0;
async function probe(page, expected, covered, caseId) {
  const rawFonts=await authoredFonts(page);
  return await page.evaluate(
    async ({ expected, wanted, fieldMap, covered, caseId, rawFonts }) => {
      const missing = wanted.filter((v) => !covered.includes(v)),
        candidates = new Map(),
        errors = [],
        ruleRecords = [];
      const scope = document.querySelector("#theme-scope");
      function add(node, pseudo, selector, style, order) {
        const rect = node.getBoundingClientRect(),
          computed = getComputedStyle(node, pseudo);
        if (!rect.width || !rect.height || computed.display === "none") return;
        if (pseudo === "::placeholder" && !node.getAttribute("placeholder"))
          return;
        if (
          ["::before", "::after"].includes(pseudo) &&
          ["none", "normal"].includes(computed.content)
        )
          return;
        for (const property of new Set([
          ...style,
          "font",
          "padding",
          "margin",
          "border",
          "border-color",
          "border-radius",
          "background",
          "gap",
        ])) {
          const value = style.getPropertyValue(property);
          for (const match of value.matchAll(/var\(\s*(--openui-[\w-]+)/g)) {
            const variable = match[1];
            if (!missing.includes(variable)) continue;
            const key = variable + "|" + selector + "|" + property;
            if (!candidates.has(key))
              candidates.set(key, {
                node,
                pseudo,
                selector,
                property,
                declared: value,
                variable,
                order,
              });
          }
        }
      }
      let order = 0;
      function walk(rules) {
        for (const r of rules) {
          const position = order++;
          if (
            r.type === CSSRule.MEDIA_RULE &&
            !matchMedia(r.conditionText).matches
          )
            continue;
          if (
            r.type === CSSRule.SUPPORTS_RULE &&
            !CSS.supports(r.conditionText)
          )
            continue;
          if (r.selectorText && r.style) {
            let selector = r.selectorText,
              pseudo = null;
            const match = selector.match(
              /::(before|after|placeholder|marker)\b/,
            );
            if (match) {
              pseudo = "::" + match[1];
              selector = selector.replace(match[0], "");
            } else if (selector.includes("::")) continue;
            try {
              for (const node of document.querySelectorAll(selector))
                if (
                  scope.contains(node) ||
                  node.closest('[class*="openui-theme-portal-"]')
                )
                  add(node, pseudo, r.selectorText, r.style, position);
            } catch (e) {
              errors.push({ selector, error: String(e) });
            }
          }
          if (r.cssRules) walk(r.cssRules);
        }
      }
      for (const s of document.styleSheets)
        try {
          walk(s.cssRules);
        } catch (e) {
          errors.push({ sheet: s.href, error: String(e) });
        }
      for (const node of document.querySelectorAll("#theme-scope [style]"))
        add(node, null, "inline " + node.tagName, node.style, order++);
      for(const row of rawFonts){
        if(row.conditions.some(c=>c.name==='media'?!matchMedia(c.params).matches:!CSS.supports(c.params)))continue;
        let selector=row.selector,pseudo=null;const match=selector.match(/::(before|after|placeholder|marker)\b/);if(match){pseudo='::'+match[1];selector=selector.replace(match[0],'')}else if(selector.includes('::'))continue;
        try{for(const node of document.querySelectorAll(selector)){
          if(!scope.contains(node)&&!node.closest('[class*="openui-theme-portal-"]'))continue;
          const rect=node.getBoundingClientRect(),computed=getComputedStyle(node,pseudo);if(!rect.width||!rect.height||computed.display==='none')continue;if(['::before','::after'].includes(pseudo)&&['none','normal'].includes(computed.content))continue;if(pseudo==='::placeholder'&&!node.getAttribute('placeholder'))continue;
          for(const match of row.value.matchAll(/var\(\s*(--openui-[\w-]+)/g)){
            const variable=match[1];if(!missing.includes(variable))continue;
            const key=variable+'|'+row.selector+'|font';if(!candidates.has(key))candidates.set(key,{node,pseudo,selector:row.selector,property:'font',declared:row.value,variable,order:'Authored Goober stylesheet; CSSOM shorthand getter loses reset-only fields'});
          }
        }}catch(e){errors.push({selector,error:String(e)})}
      }
      let proofs = [],
        attempts = [];
      for (const c of candidates.values()) {
        if (proofs.some((p) => p.variable === c.variable)) continue;
        const field = fieldMap[c.variable],
          expectedValue = expected[field],
          beforeStyle = getComputedStyle(c.node, c.pseudo),
          resolved = beforeStyle.getPropertyValue(c.variable).trim();
        if (resolved !== expectedValue) {
          attempts.push({
            caseId,
            variable: c.variable,
            field,
            status: "Wrong resolved variable",
            actual: resolved,
            expected: expectedValue,
            selector: c.selector,
          });
          continue;
        }
        const mappings = [];
        for (const sheet of document.styleSheets)
          for (const r of sheet.cssRules ?? [])
            if (
              r.style &&
              r.selectorText
                ?.split(",")
                .map((s) => s.trim())
                .includes("#theme-scope") &&
              r.style.getPropertyValue(c.variable)
            )
              mappings.push(r);
        if (!mappings.length) {
          attempts.push({
            caseId,
            variable: c.variable,
            status: "Missing provider mapping",
          });
          continue;
        }
        const readValue = () => {
          const style = getComputedStyle(c.node, c.pseudo);
          if (c.property === "font")
            return JSON.stringify(
              Object.fromEntries(
                [
                  "font-family",
                  "font-size",
                  "font-weight",
                  "font-style",
                  "font-stretch",
                  "line-height",
                ].map((p) => [p, style.getPropertyValue(p)]),
              ),
            );
          return style.getPropertyValue(c.property);
        };
        const before = readValue(),
          durations = beforeStyle.transitionDuration
            .split(",")
            .map((s) => parseFloat(s) * (s.trim().endsWith("ms") ? 1 : 1000)),
          transitions = beforeStyle.transitionProperty
            .split(",")
            .map((s) => s.trim());
        const wait = transitions.some(
          (p) =>
            p === "all" ||
            p === c.property ||
            p.startsWith(c.property + "-") ||
            c.property.startsWith(p + "-"),
        )
          ? Math.max(0, ...durations)
          : 0;
        const saved = mappings.map((r) => ({
          r,
          value: r.style.getPropertyValue(c.variable),
          priority: r.style.getPropertyPriority(c.variable),
        }));
        for (const s of saved) s.r.style.removeProperty(c.variable);
        const detected = mappings.every(
          (r) => !r.style.getPropertyValue(c.variable),
        );
        await new Promise((r) => setTimeout(r, wait + 35));
        const connected = c.node.isConnected,
          after = connected ? readValue() : null;
        for (const s of saved)
          s.r.style.setProperty(c.variable, s.value, s.priority);
        await new Promise((r) => setTimeout(r, wait + 35));
        const restored =
          c.node.isConnected &&
          getComputedStyle(c.node, c.pseudo)
            .getPropertyValue(c.variable)
            .trim() === expectedValue;
        const row = {
          caseId,
          variable: c.variable,
          field,
          selector: c.selector,
          pseudo: c.pseudo,
          property: c.property,
          declared: c.declared,
          ruleOrder: c.order,
          tag: c.node.tagName,
          className: c.node.getAttribute("class"),
          expected: expectedValue,
          resolved,
          before,
          removedMappingValue: after,
          negativeDetected: detected,
          connected,
          restored,
          transitionWaitMs: wait,
        };
        if (connected && restored && detected && before !== after) {
          proofs.push({
            ...row,
            status:
              "Passed: expected variable on actual consumer, provider mapping required, computed property depends on token",
          });
        } else
          attempts.push({
            ...row,
            status: !connected
              ? "Consumer replaced during mutation"
              : !restored
                ? "Restoration failed"
                : before === after
                  ? "Matched declaration not proven to affect winning computed property"
                  : "Negative control failed",
          });
      }
      return { caseId, proofs, attempts, errors };
    },
    { expected, wanted, fieldMap, covered: [...covered], caseId, rawFonts },
  );
}
try {
  const page = await openPage(browser, "wiring-v2");
  for (const f of fixtures) {
    const prior = JSON.parse(
      await fs.readFile(
        out + "/token-v2-" + f.preset + "-" + f.mode + ".json",
        "utf8",
      ),
    );
    const covered = new Set(prior.covered),
      scheme = { preset: f.preset, mode: f.mode, full: true };
    const run = async (config, label) => {
      await render(page, { ...scheme, ...config });
      const p = await probe(page, f.full, covered, label);
      for (const x of p.proofs) covered.add(x.variable);
      results.push({ ...scheme, ...p });
      cases.push({
        ...scheme,
        label,
        covered: covered.size,
        errors: await page.evaluate(() => window.fixtureObservations.errors),
        notices: await page.evaluate(() => window.fixtureObservations.notices),
        pageErrors: [...page.verificationErrors],
      });
      total++;
      await save("token-browser-v3-progress", {
        browser: browser.version(),
        total,
        current: scheme,
        covered: covered.size,
        wanted: wanted.length,
        remaining: wanted.filter((v) => !covered.has(v)),
        results,
        cases,
      });
    };
    await run({}, "direct-controls");
    for (const [label, trigger, click] of [
      ["model-hover", '#theme-scope [aria-label="Select model"]', false],
      ["select-open", '#theme-scope [aria-label="Fixture select"]', true],
      ["calendar-open", "#theme-scope .openui-calendar-select-trigger", true],
      ["tooltip-open", '#theme-scope [aria-label="Fixture tooltip"]', false],
    ]) {
      if (click) await page.locator(trigger).first().click();
      else await page.locator(trigger).first().hover();
      await settle(page, 220);
      const p = await probe(page, f.full, covered, label);
      for (const x of p.proofs) covered.add(x.variable);
      results.push({ ...scheme, ...p });
      await page.keyboard.press("Escape");
      await page.mouse.move(-10, -10);
      await settle(page, 180);
    }
    for (const action of ["hover", "focus"]) {
      if (action === "hover")
        await page
          .locator('#theme-scope [aria-label="Ordinary input"]')
          .hover();
      else
        await page
          .locator('#theme-scope [aria-label="Ordinary input"]')
          .focus();
      await settle(page, 180);
      const p = await probe(page, f.full, covered, "direct-input-" + action);
      for (const x of p.proofs) covered.add(x.variable);
      results.push({ ...scheme, ...p });
    }
    await run({ extra: true }, "direct-typography-charts-buttons-skeletons");
    for (const state of ["hover", "active"])
      for (let n = 0; n < 6; n++) {
        const btn = page
          .locator('[data-extra="buttons"] button:not(:disabled)')
          .nth(n);
        await btn.hover();
        if (state === "active") await page.mouse.down();
        await settle(page, 180);
        const p = await probe(
          page,
          f.full,
          covered,
          "buttons-" + state + "-" + n,
        );
        for (const x of p.proofs) covered.add(x.variable);
        results.push({ ...scheme, ...p });
        if (state === "active") await page.mouse.up();
      }
    const bar=page.locator('[data-chart="BarChart"] .openui-bar-chart-bar').first();await bar.hover();await settle(page,220);{const p=await probe(page,f.full,covered,'bar-chart-tooltip');for(const x of p.proofs)covered.add(x.variable);results.push({...scheme,...p})}await page.mouse.move(-10,-10);
    await run({ extra: "modal" }, "direct-open-modal");
    await run({ extra: "composite" }, "direct-composite-inline-code-carousel");
    for (const c of inputs) {
      if (covered.size === wanted.length) break;
      if (
        c.coverage.includes("HorizontalBarChart") ||
        c.setup?.sharedSession ||
        c.setup?.directHorizontal
      ) {
        cases.push({
          ...scheme,
          label: c.id,
          status:
            "Known inherited horizontal instability or noncomponent shared-session fixture; not executed here",
        });
        continue;
      }
      if (!c.source.trim()) continue;
      await run(
        {
          caseSource: c.source,
          caseId: c.id,
          isStreaming: !!c.setup.isStreaming,
        },
        c.id,
      );
    }
    await save("token-v3-" + f.preset + "-" + f.mode, {
      browser: browser.version(),
      scheme,
      covered: [...covered],
      remaining: wanted.filter((v) => !covered.has(v)),
      proofs: results
        .filter((r) => r.preset === f.preset && r.mode === f.mode)
        .flatMap((r) => r.proofs),
    });
    console.log(
      f.preset +
        " " +
        f.mode +
        " " +
        covered.size +
        "/" +
        wanted.length +
        " tokens",
    );
  }
  await page.close();
  await save("token-browser-v3-results", {
    browser: browser.version(),
    wanted,
    fieldMap,
    results,
    cases,
  });
} finally {
  await browser.close();
}
