import React from 'react';
import {createRoot} from 'react-dom/client';
import {ThemeProvider,useTheme,Button} from '@openuidev/react-components';
import {ModelSwitcher,FollowUpItem} from '@openuidev/chat-kit';
import {openuiChatLibrary} from '@openuidev/chat-kit/libs';
import {Renderer} from '@openuidev/react-lang';
const full='root = Card([TextContent("Shared streamed content"), FollowUpBlock([FollowUpItem("Continue fixture")])])';
window.actions=[];window.renderErrors=[];
function Probe(){const {mode}=useTheme();return <output id="mode">{mode}</output>}
function App(){const [mode,setMode]=React.useState('dark');const [source,setSource]=React.useState(full);const [streaming,setStreaming]=React.useState(false);window.setMode=setMode;window.setChunk=(n)=>{setStreaming(n<full.length);setSource(full.slice(0,n))};window.sourceLength=full.length;return <ThemeProvider mode={mode} darkTheme={{textNeutralPrimary:'#12ab34'}} lightTheme={{textNeutralPrimary:'#ab1234'}}><Probe/><Button onClick={()=>window.actions.push('direct')}>Direct action</Button><ModelSwitcher value="a" onValueChange={v=>window.actions.push(v)} models={[{id:'a',name:'Model A',logo:{light:<span>LIGHT LOGO</span>,dark:<span>DARK LOGO</span>}}]}/><FollowUpItem text="Root followup" onClick={()=>window.actions.push('root')}/><div id="rendered"><Renderer response={source} library={openuiChatLibrary} isStreaming={streaming} onAction={v=>window.actions.push(v)} onError={v=>window.renderErrors=v}/></div></ThemeProvider>}
createRoot(document.getElementById('root')!).render(<App/>);
