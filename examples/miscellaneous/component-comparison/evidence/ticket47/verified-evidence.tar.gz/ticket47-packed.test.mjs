import {test} from 'node:test';
import assert from 'node:assert/strict';
import {spawnSync} from 'node:child_process';
const cwd=process.env.TICKET47_CONSUMER??'/private/tmp/ticket47-consumer';
test('clean packed consumer imports the standalone chat components from the package root',()=>{
 const result=spawnSync(process.execPath,['--input-type=module','-e',`import * as chat from '@openuidev/chat-kit'; console.log(JSON.stringify(Object.keys(chat).sort()));`],{cwd,encoding:'utf8'});
 assert.equal(result.status,0,result.stderr);assert.deepEqual(JSON.parse(result.stdout),['FollowUpBlock','FollowUpItem','ModelSwitcher']);
});
