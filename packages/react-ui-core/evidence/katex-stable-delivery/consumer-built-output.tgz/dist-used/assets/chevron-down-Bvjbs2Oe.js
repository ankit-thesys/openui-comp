import{a as o}from"./index-CnLgm2Wu.js";/**
 * @license lucide-react v0.562.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const e=[["path",{d:"m6 9 6 6 6-6",key:"qrunsl"}]],c=o("chevron-down",e);export{e as __iconNode,c as default};
