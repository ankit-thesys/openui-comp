import{a as c}from"./index-CnLgm2Wu.js";/**
 * @license lucide-react v0.562.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const e=[["circle",{cx:"12",cy:"19",r:"2",key:"13j0tp"}],["circle",{cx:"12",cy:"5",r:"2",key:"f1ur92"}],["circle",{cx:"16",cy:"12",r:"2",key:"4ma0v8"}],["circle",{cx:"20",cy:"19",r:"2",key:"1obnsp"}],["circle",{cx:"4",cy:"19",r:"2",key:"p3m9r0"}],["circle",{cx:"8",cy:"12",r:"2",key:"1nvbw3"}]],i=c("circle-pile",e);export{e as __iconNode,i as default};
