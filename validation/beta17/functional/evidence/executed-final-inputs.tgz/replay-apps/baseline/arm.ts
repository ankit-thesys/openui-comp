import '@openuidev/react-ui/styles/index.css';
export {ThemeProvider,openuiChatLibrary} from '@openuidev/react-ui';
