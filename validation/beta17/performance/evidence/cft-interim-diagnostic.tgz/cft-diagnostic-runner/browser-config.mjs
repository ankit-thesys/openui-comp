import { createHash } from "node:crypto";
import fs from "node:fs/promises";
import path from "node:path";

export async function browserLaunchOptions(manifest) {
  const browser = manifest.browser;
  if (
    !browser ||
    browser.name !== "chrome-for-testing" ||
    !/^\d+\.\d+\.\d+\.\d+$/.test(browser.version) ||
    !browser.platform ||
    !path.isAbsolute(browser.executablePath ?? "") ||
    !/^[a-f0-9]{64}$/.test(browser.executableSha256 ?? "")
  )
    throw new Error("Complete pinned Chrome for Testing identity is required");
  const official = `https://storage.googleapis.com/chrome-for-testing-public/${browser.version}/${browser.platform}/chrome-${browser.platform}.zip`;
  if (browser.source !== official)
    throw new Error("Browser source must match the official pinned distribution");
  if (manifest.inputs?.[browser.executablePath] !== browser.executableSha256)
    throw new Error("Pinned browser missing or different in frozen input inventory");
  const actual = createHash("sha256")
    .update(await fs.readFile(browser.executablePath))
    .digest("hex");
  if (actual !== browser.executableSha256)
    throw new Error("Pinned browser executable hash changed");
  return { executablePath: browser.executablePath, headless: true };
}
