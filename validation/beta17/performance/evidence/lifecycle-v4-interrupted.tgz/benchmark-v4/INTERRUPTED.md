# V4 attempt — interrupted, no performance acceptance

Manifest SHA256:
`7de0f135e2d41b5f715c1c00e775fa507291baf1c5df41f3b36bc2342b7c1581`.
The startup snapshot contains the frozen739b4af6b cleanup source. This fresh
attempt did not reuse V3 observations.

The runner saved2 excluded first streams and20/80 measured samples (chat/paced),
then stopped updating the report. At02:45 process elapsed, a normal operator
listing showed the owned Node process69091 still alive and no automated Chrome
process. The process was stopped with SIGTERM/exit143; the W1 server was left
untouched. Its last exact report is preserved; `summary-incomplete.json` rejects
it. No final matrix or soak result exists and no sample is reused later.

`interrupted-postcheck.json` confirms **all frozen input hashes and independent
installed package hashes still match**. No frozen source, product, W1 fixture,
client, transport, server, payload or served asset changed in this attempt.

## Separate lifecycle diagnostic, outside formal measurement

`../v4-lifecycle-diagnostic.log` records standard `DEBUG=pw:api` logging plus
public call-boundary markers, from `../../diagnose-transition.mjs`. It replays
one excluded stream/arm and ten alternating pairs in chat/paced, then closes
both clients and owning servers. These are diagnostic replays, not acceptance
samples. The diagnostic exited0; all browser resources closed without forcing.

Both client-close calls returned promptly. Both server-close calls eventually
returned. Last API completion was at15:57:51.752Z; the completed log modification
time was15:58:15.502Z, approximately23.75s later. This shows delayed server
shutdown in the diagnostic; it **does not prove** a permanent deadlock or fully
localize the longer formal stall. The short preflight/smoke checks did not
establish full-run progress. Do not attribute this to Goober or product code.

The runtime driver currently creates an owned Playwright BrowserServer and a
connected Browser for each arm. A conventional alternative is direct stock
`chromium.launch({channel:"chrome",headless:true})` per arm, avoiding the extra
server/connection layer. CDP process enumeration already supplies owned RSS
process IDs, so it does not require BrowserServer. This is a **proposal**, not
an implemented or accepted fix. Diagnose or simplify the lifecycle and verify
the full repeated-stream-to-next-cell transition before another formal attempt.

No further frozen runner change was made. The first diagnostic closed all owned resources. Root then authorized a bounded
full-runner lifecycle trace while Worker2 retains the quiet browser window.
Final release is recorded with that diagnostic handoff. W1 owns server stop.
There is no product or performance verdict and neither ten-minute soak has run.
