# @openuidev/react-components (beta)

Reusable OpenUI React components, charts and themes. This additive package keeps
existing component props, appearance and behavior while converting owned styles
to stock Goober. The existing `@openuidev/react-ui` remains unchanged.

## Imports and customization

All public components, supporting parts and types come from the package root.
There are no component subpath exports or new styling props.

```tsx
import { Button, Input, TextArea, ThemeProvider } from "@openuidev/react-components";

export function ContactForm() {
  return (
    <ThemeProvider>
      <Input aria-label="Name" size="medium" />
      <TextArea aria-label="Message" rows={3} />
      <Button variant="primary" type="submit">
        Send
      </Button>
    </ThemeProvider>
  );
}
```

The root includes inputs and controls; layout containers and their parts;
text, Markdown, images and citations; loading and help; tables, lists and composed
cards; and the existing chart families. Existing variants, native attributes,
refs, `className`, `style` and component-specific customization remain available.
Input also retains its existing `styles` alias. OptionCards remains controlled:
update `selected` in response to `onToggle`.

## Themes

```tsx
import { createTheme, ThemeProvider, useTheme } from "@openuidev/react-components";

const brand = createTheme({ interactiveAccentDefault: "oklch(0.6 0.2 260 / 1)" });

export function App() {
  return <ThemeProvider lightTheme={brand}>{/* application */}</ThemeProvider>;
}
```

Existing `lightTheme`, `darkTheme`, `mode`, deprecated `theme` and `cssSelector`
props are preserved. `useTheme`, default themes, swatches, theme types and
system/preference hooks and constants are public; theme context objects remain
private. LayoutContext/LayoutContextProvider/useLayoutContext and
PrintContext/PrintContextProvider/usePrintContext retain their public APIs.

A top-level provider targets `body` by default. Nested providers scope their
tokens automatically. For independent top-level themes, use separate existing
`cssSelector` targets. `useTheme().portalThemeClassName` retains the portal theme
mechanism. `useThemeModePreference` keeps JSON localStorage preferences and the
`data-openui-theme` document attribute; it does not synchronize separate hook
instances or browser tabs.

## Automatic styles

Owned component styles use unmodified Goober module-scope `css` calls and do not
require a CSS import, setup command or styling build plugin. Styles register
when a referenced module evaluates, before the component renders. The build
preserves modules and marks unused modules removable by the consumer's bundler.
A bundler may combine several retained components in a shared lazy chunk; their
styles can register together when that chunk evaluates. This is not a guarantee
of a separate stylesheet or network chunk for each component.

Importing the package also registers the existing light-theme token defaults on
the document root, without a provider. These defaults occupy the first CSS layer,
so normal host token declarations override them, including declarations in named
layers. Inherited container overrides and ThemeProvider scopes remain supported;
system dark mode does not change the provider-free defaults.

Component-level `var()` fallbacks are intentionally retained. Clearing an
inherited token, for example with `--openui-interactive-accent-default: initial`,
still uses the component's existing default. Automatic root defaults complement
that behavior; they do not replace the fallback when a consumer clears a token.

Buttons, FormControl and TagBlock share a root-only `box-sizing: border-box`
declaration. Descendant styling, component layout and state rules remain local.

Chrome with plain CSS, Tailwind v3 and Tailwind v4 is the current browser target.
Host preflight remains enabled. Ordinary utility classes do not necessarily beat
component defaults. Intentional overrides can use scoped important CSS or the
framework's important utility modifier: Tailwind v3 `!bg-red-500`, Tailwind v4
`bg-red-500!`. Existing component props, inline styles and theme tokens remain
the primary customization APIs. Replacing host styles dynamically after mount
has not been certified.

### Stable selector pilot

Button and IconButton use stable styling targets. Importing either component
registers its rules automatically through stock Goober. A private generated class
on `html` is contained in `:where(...:root)` and adds zero specificity. Consumers
do not use that class. Families outside the documented batches below still use generated selectors.

| Target | Button | IconButton |
| --- | --- | --- |
| Root | `.openui-button-root` | `.openui-icon-button-root` |
| Preserved root alias | `.openui-button-base` | `.openui-icon-button` |
| Variant | `.openui-button-base-primary` (also secondary/tertiary) | `.openui-icon-button-primary` (also secondary/tertiary) |
| Destructive variant | `.openui-button-base-destructive-primary` (also secondary/tertiary) | `.openui-icon-button-destructive-primary` (also secondary/tertiary) |
| Size | `.openui-button-base-{extra-small,small,medium,large}` | `.openui-icon-button-{3-extra-small,2-extra-small,extra-small,small,medium,large}` |
| Shape | Existing Button geometry | `.openui-icon-button-square`, `.openui-icon-button-circle` |
| State | `:hover:not(:disabled)`, `:active:not(:disabled)`, `:disabled` | Same |
| Owned part | No added wrapper around children or icons | `.openui-icon-button-icon` (existing span) |

Use ordinary **later, unlayered CSS** with the corresponding selector. Root rules
have one class of specificity; variants, sizes, states and parts retain their
additional selectors. For example:

```css
.openui-button-root { border-width: 2px; }
.openui-button-root.openui-button-base-primary { background: navy; }
.openui-button-root.openui-button-base-primary:disabled { cursor: wait; }
.openui-icon-button-root .openui-icon-button-icon { gap: 4px; }
```

No `!important` is required for these matching overrides. This does not promise
that earlier CSS, a root-only selector against a variant rule, or normal CSS in a
named layer beats unlayered component rules. Existing props, inline styles and
theme APIs remain unchanged; no new styling prop is introduced. Old root aliases
remain available on actual components. Host elements carrying only those old
aliases do not acquire the new component styles.

The shared `openui-border-box` helper opts in only Buttons, FormControl and
TagBlock roots. A later root class can override its box sizing. It does not style
descendants. The control batch below also converts FormControl's remaining
owned rules; Buttons and TagBlock still have shared-base-only conversion.

### Control selectors

The control batch adds the following stable styling roots. Existing aliases,
parts, variants, native attributes, refs and customization props are retained.
No rendered wrapper is added. Component styles use the same private
zero-specificity document guard as the Button/IconButton pilot.

| Family | Styling root | Existing parts and states |
| --- | --- | --- |
| CheckBoxGroup | `.openui-checkbox-group-root` | Existing clear/card/sunk variant classes. |
| CheckBoxItem | `.openui-checkbox-item-container-root` | Container root; `.openui-checkbox-item-root`, indicator, content, label and description; checked/disabled states stay on the Radix control. |
| Chips | `.openui-chips-root` | Existing chip item, icon and text; selected/disabled modifiers and focus-visible state. |
| FormControl | `.openui-form-control-root`, `.openui-hint-root` | FormControl and Hint roots; error context still reaches Input/TextArea/Hint. |
| Input | `.openui-input-root` | Existing small/medium/large, error, focus, hover, disabled and placeholder selectors. |
| Label | `.openui-label-root` | Existing disabled modifier and required-asterisk part. |
| OptionCards | `.openui-option-cards-root` | Existing grid/row/card/content/text/title/subtitle/top parts; selected/disabled/focus-visible state and container queries. |
| RadioGroup | `.openui-radio-group-root` | Existing clear/card/sunk variants; native Radix behavior. |
| RadioItem | `.openui-radio-item-container-root` | Container root; existing control, SVG paths, content, label and description; checked/disabled states. |
| Slider | `.openui-slider-wrapper-root`, `.openui-slider-block-root` | Wrapper and SliderBlock roots; existing track/range/thumb/handle/value/dot/label/block parts and native disabled/focus/hover state. |
| SwitchGroup | `.openui-switch-group-root` | Existing clear/card/sunk variants. |
| SwitchItem | `.openui-switch-item-container-root` | Container root; existing control/thumb/content/label/description and checked/disabled states. |
| TextArea | `.openui-textarea-root` | Existing error, focus, hover and disabled selectors. |
| ToggleGroup | `.openui-toggle-group-root` | Existing group root and native disabled behavior. |
| ToggleItem | `.openui-toggle-item-root` | Existing item alias and on/off, hover and disabled state. |

For example, a later `.openui-input-root { border-width: 2px; }` overrides
Input's base border width. Use the corresponding variant, state or part selector
when overriding a declaration owned there:

```css
.openui-input-root:focus { box-shadow: none; }
.openui-checkbox-item-container-root .openui-checkbox-item-root[data-state="checked"] {
  background-color: navy;
}
.openui-toggle-item-root[data-state="on"] { background-color: navy; }
```

The Slider `className` still applies to its inner Radix root, while the new
styling root identifies its existing outer wrapper. Checkbox/Radio/Switch
`className` forwarding likewise remains on their existing control elements.
Vendor inline styles are preserved: for example Radix RadioGroup and
ToggleGroup retain inline `outline: none`. The ordinary CSS override contract
covers the component's owned stylesheet declarations; it does not promise to
beat inline styles without using the existing inline customization API.

### Select, Calendar, DatePicker and Modal selectors

These families retain their existing props, markup, behavior and theme delivery.
Ordinary overrides require the corresponding later, unlayered selector. Floating
coordinates and other existing inline styles keep their current precedence.

| Family | Stable styling targets | Scope |
| --- | --- | --- |
| Select | `.openui-select-trigger-root`, `.openui-select-content-root`, `.openui-select-viewport-root`, `.openui-select-group-root`, `.openui-select-label-root`, `.openui-select-item-root`, `.openui-select-separator-root` | Existing trigger, portaled content and parts; existing aliases, size classes, placeholder/open/checked/highlighted/disabled state remain. |
| Calendar | `.openui-calendar-container-root` | Existing outer wrapper scopes the existing DayPicker classes; owned declarations primarily target its parts, not the wrapper itself. `classNames` overrides keep their current behavior. |
| DatePicker | `.openui-date-picker-style-root` | Marks both the existing floating container and portal content. Qualify with their existing aliases when styling one role. Floating UI's inline coordinates are preserved. |
| Modal | `.openui-modal-portal-root`, `.openui-modal-overlay-root`, `.openui-modal-content-root`, `.openui-modal-header-root`, `.openui-modal-title-root`, `.openui-modal-close-root`, `.openui-modal-body-root` | Existing portal and parts; sizes, close paths and supported props remain unchanged. |

```css
.openui-select-trigger-root:where(.openui-select-trigger-sm) { padding-left: 24px; }
.openui-select-content-root.openui-select-content-sm .openui-select-label { font-size: 14px; }
.openui-calendar-container-root .openui-calendar-single-day-selected { background: navy; }
.openui-date-picker-style-root:where(.openui-date-picker-renderer-floating-content) { z-index: 60; }
.openui-modal-close-root:focus-visible { outline-color: navy; }
```

Calendar's custom dropdowns still use Select's private content/viewport exports;
this internal dependency is preserved. Select, DatePicker, Modal and Calendar
month dropdowns keep their existing nested-theme behavior in real portals.
These client checks do not establish SSR, hydration or concurrent server support.

### Selector conversion status

This inventory describes the selector pilot, not a completed package-wide
conversion. All existing token fallbacks remain in place.

| Status | Families |
| --- | --- |
| Converted; new batches pending independent acceptance | Button, IconButton, CheckBoxGroup, CheckBoxItem, Chips, FormControl, Input, Label, OptionCards, RadioGroup, RadioItem, Slider, SwitchGroup, SwitchItem, TextArea, ToggleGroup, ToggleItem, Select, Calendar, DatePicker, Modal |
| Shared box sizing only; remaining selectors pending | Buttons, TagBlock |
| Deferred to #63 | Accordion, Callout, Card, CardHeader, Carousel, CodeBlock, CompositeCardBlock, ContextCardBlock, DotMatrixLoader, EditableTable, EntityList, IconTag, IconText, Image, ImageBlock, ImageText, ImageTextLarge, InlineHeader, InlineMarkdownRenderer, ListBlock, ListItem, MarkDownRenderer, MetricIndicator, OverviewCardBlock, SectionBlock, Separator, Skeleton, SnippetCardBlock, SourceFaviconImage, Sources, Steps, Table, Tabs, Tag, TextBlock, TextCallout, TextContent, TextContentWrapper, VisualCardBlock |
| Deferred to #64 | Citation, ImageGallery, TooltipWrapper |

Charts retain their current selectors; their Button/IconButton controls consume
the pilot indirectly. Later tickets must review each owned root, variant, state
and part before declaring a family converted. Calendar's direct imports of
Select content/viewport styles remain unchanged and require coordinated review.

EditableTable remains a complex deferred candidate, not an automatic exception
for all its owned wrappers. Markdown/code wrapper styles can migrate separately
from vendor syntax themes and KaTeX. Dynamic geometry and per-instance colors,
React inline styles, ThemeProvider serialization and official vendor CSS retain
their existing contracts; animations alone do not justify skipping owned styles.
SourceFaviconImage's existing hook applies to the successful image, not its
shared icon fallback. TextContent's existing `text-content` aliases are preserved.

### Math styles and fonts

TextContentWrapper retains its lazy math renderer and automatically imports
official KaTeX CSS/fonts from a private module. This accepted vendor-style
exception does not import legacy SCSS. The default Vite6.4.2 production build
handles it without consumer styling setup. Other bundlers need validation;
bare esbuild requires font loaders and application CSS linking.

Vite can emit about1.07MB of unused font assets. This accepted output cost does
not mean the browser downloads them on a Button-only page. The wrapper loads
its math module whenever mounted, including non-math text.

## Charts

```tsx
import { PieChart, ThemeProvider } from "@openuidev/react-components";

export function RevenueShare() {
  return (
    <ThemeProvider>
      <PieChart
        data={[
          { name: "Subscriptions", revenue: 80 },
          { name: "Services", revenue: 20 },
        ]}
        categoryKey="name"
        dataKey="revenue"
        variant="donut"
        height={320}
      />
    </ThemeProvider>
  );
}
```

Available entries include AreaChart/AreaChartCondensed,
LineChart/LineChartCondensed, BarChart/BarChartCondensed/HorizontalBarChart,
PieChart, RadialChart, RadarChart, ScatterChart, HeatmapChart, FunnelChart,
CalendarHeatmap, SegmentedBar, SingleStackedBar (the existing alias),
MiniAreaChart, MiniBarChart and MiniLineChart. Existing data/prop types, Scatter
helpers, LegendStoreProvider/useLegendEntry, StackedLegend and CHART_CLASS_PREFIX
are also public. Shared chart implementations remain private.

## Support boundary and inherited behavior

React/ReactDOM19 are required. Zod3.25+ or4 and Zustand4.5.5+ remain peer
dependencies. **SSR, hydration, streaming SSR and concurrent server style
isolation are deferred.** Node imports and declarations do not establish SSR
support. Client-side OpenUI response streaming is a separate capability.

Extraction preserves inherited behavior rather than redesigning it:

- HorizontalBar's `onClick` remains unwired; numeric width affects scales without
  setting the CSS box. String height with a fitting legend can cause sizing
  feedback, and that combination does not have a passing strict comparison.
- Scatter retains no print-export metadata, and its public domain helper clamps
  negative lower bounds.
- EditableTable can notify `onDataChange` twice when Enter-save is followed by blur.
- Modal and TooltipWrapper retain their existing focus, labeling and child-ref
  constraints. Consumers must provide accessible labels and appropriate children.

## Development

```sh
pnpm --filter @openuidev/react-components run build
pnpm --filter @openuidev/react-components run ci
```

ESM/CJS builds include matching declarations and source maps. Goober and React
remain external dependencies. Build inputs contain no old SCSS or generated CSS.

### Authoring styles

Component declarations and keyframes use stock Goober tagged template strings.
Reusable declaration fragments are plain template strings, interpolated where
needed; registration remains at the existing module-level call site:

```ts
const body = `
  font: var(--openui-text-body-default, 400 16px/1.5 "Inter", sans-serif);
`;
const rootClass = css`
  ${body}
  display: flex;
  &:disabled {
    cursor: not-allowed;
  }
`;
```

Keep selector specificity, declaration order, token fallbacks and keyframe timing
when editing styles. Use CSS units explicitly: Goober does not add `px` to numeric
object values. Class-name maps are ordinary objects containing registered classes;
they are not CSS declaration objects.

The following retain their existing non-template contracts:

- Native `style` forwarding and computed chart geometry/animation values are
  per-instance React styles.
- ThemeProvider serializes scoped theme variables through its existing lifecycle.
- Syntax-highlighter theme maps use the third-party component's object API.
- KaTeX keeps its official vendor CSS and font assets.

These exceptions do not justify new static Goober declaration objects, custom
serializers or styling APIs.

## Beta import migration

Use `@openuidev/react-components` in place of the previous unpublished beta name
`@openuidev/react-ui-core`. The folder is now `packages/react-components`. There
is no compatibility alias. Component names, root-only exports, public types and
customization APIs are preserved. The existing `@openuidev/react-ui` package stays
unchanged. Historical validation artifact names remain valid for their recorded
baselines.
